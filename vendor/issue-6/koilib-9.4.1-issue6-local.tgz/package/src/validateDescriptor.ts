/**
 * Validate JSON protobuf descriptors before they reach protobufjs reflection.
 * The binary descriptor path goes through the protobuf text parser instead.
 */
const identifier = /^[A-Za-z_][A-Za-z_0-9]*$/;
const qualifiedName = /^\.?[A-Za-z_][A-Za-z_0-9]*(\.[A-Za-z_][A-Za-z_0-9]*)*$/;
const maxDepth = 64;
const maxNodes = 100000;

type JsonObject = Record<string, unknown>;

function object(value: unknown, location: string): JsonObject {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new Error("invalid ABI descriptor at " + location);
  return value as JsonObject;
}

function name(value: string, location: string): void {
  if (!identifier.test(value))
    throw new Error("invalid ABI identifier at " + location);
}

function reference(value: unknown, location: string): void {
  if (typeof value !== "string" || !qualifiedName.test(value))
    throw new Error("invalid ABI reference at " + location);
}

function fieldProperties(field: JsonObject, location: string): void {
  reference(field.type, location + ".type");
  if (!Number.isInteger(field.id) || (field.id as number) < 1)
    throw new Error("invalid ABI field id at " + location);
  if (field.keyType !== undefined)
    reference(field.keyType, location + ".keyType");
  if (field.extend !== undefined) reference(field.extend, location + ".extend");
  if (
    field.rule !== undefined &&
    field.rule !== "optional" &&
    field.rule !== "required" &&
    field.rule !== "repeated" &&
    field.rule !== "proto3_optional"
  )
    throw new Error("invalid ABI field rule at " + location);
}

export function validateDescriptor(value: unknown): void {
  const seen = new WeakSet<object>();
  const optionAncestors = new WeakSet<object>();
  let nodes = 0;

  function budget(depth: number): void {
    if (depth > maxDepth || ++nodes > maxNodes)
      throw new Error("ABI descriptor exceeds validation limits");
  }

  function optionValue(option: unknown, location: string, depth: number): void {
    budget(depth);
    if (
      option === null ||
      typeof option === "string" ||
      typeof option === "boolean" ||
      (typeof option === "number" && Number.isFinite(option))
    )
      return;
    if (typeof option !== "object")
      throw new Error("invalid ABI option at " + location);
    if (optionAncestors.has(option))
      throw new Error("cyclic ABI option at " + location);
    optionAncestors.add(option);
    for (const [key, child] of Object.entries(option))
      optionValue(child, location + "." + key, depth + 1);
    optionAncestors.delete(option);
  }

  function options(value: unknown, location: string, depth: number): void {
    const entries = object(value, location);
    for (const [key, option] of Object.entries(entries)) {
      // Custom aggregate/repeated options and edition feature objects are
      // legitimate JSON data. A field default, however, must remain scalar.
      if (key === "default" && (option === null || typeof option === "object"))
        throw new Error("invalid ABI option at " + location + "." + key);
      if (
        (key === "packed" || key === "proto3_optional") &&
        typeof option !== "boolean"
      )
        throw new Error("invalid ABI option at " + location + "." + key);
      optionValue(option, location + "." + key, depth);
    }
  }

  function fieldDefault(field: JsonObject, location: string): void {
    const value = (field.options as JsonObject | undefined)?.default;
    if (value === undefined) return;
    if (
      ((field.type === "bytes" || field.type === "string") &&
        typeof value !== "string") ||
      (field.type === "bool" && typeof value !== "boolean")
    )
      throw new Error("invalid ABI option at " + location + ".options.default");
  }

  function visit(
    valueToVisit: unknown,
    location: string,
    depth: number
  ): JsonObject {
    budget(depth);
    const entry = object(valueToVisit, location);
    if (seen.has(entry))
      throw new Error("cyclic ABI descriptor at " + location);
    seen.add(entry);
    if (entry.options !== undefined)
      options(entry.options, location + ".options", depth + 1);
    return entry;
  }

  function visitField(
    valueToVisit: unknown,
    location: string,
    depth: number
  ): void {
    const field = visit(valueToVisit, location, depth);
    fieldProperties(field, location);
    fieldDefault(field, location);
  }

  function visitNamespace(
    valueToVisit: unknown,
    location: string,
    depth: number
  ): void {
    const entry = visit(valueToVisit, location, depth);
    // Extensions are represented as fields inside `nested`, while a
    // synthetic oneof marker may appear as a nested object as well.
    if (entry.id !== undefined) {
      fieldProperties(entry, location);
      fieldDefault(entry, location);
    }
    if (entry.oneof !== undefined) {
      if (!Array.isArray(entry.oneof))
        throw new Error("invalid ABI oneof at " + location);
      for (const member of entry.oneof) reference(member, location + ".oneof");
    }
    if (entry.fields !== undefined) {
      const fields = object(entry.fields, location + ".fields");
      for (const [fieldName, field] of Object.entries(fields)) {
        name(fieldName, location + ".fields");
        visitField(field, location + ".fields." + fieldName, depth + 1);
      }
    }
    if (entry.oneofs !== undefined) {
      const oneofs = object(entry.oneofs, location + ".oneofs");
      for (const [oneofName, oneof] of Object.entries(oneofs)) {
        name(oneofName, location + ".oneofs");
        const declaration = visit(
          oneof,
          location + ".oneofs." + oneofName,
          depth + 1
        );
        if (!Array.isArray(declaration.oneof))
          throw new Error(
            "invalid ABI oneof at " + location + ".oneofs." + oneofName
          );
        for (const member of declaration.oneof)
          reference(member, location + ".oneofs." + oneofName);
      }
    }
    if (entry.values !== undefined) {
      const values = object(entry.values, location + ".values");
      for (const [valueName, number] of Object.entries(values)) {
        name(valueName, location + ".values");
        if (typeof number !== "number" || !Number.isInteger(number))
          throw new Error(
            "invalid ABI enum value at " + location + ".values." + valueName
          );
      }
    }
    if (entry.valuesOptions !== undefined) {
      const valuesOptions = object(
        entry.valuesOptions,
        location + ".valuesOptions"
      );
      for (const [valueName, option] of Object.entries(valuesOptions)) {
        name(valueName, location + ".valuesOptions");
        options(option, location + ".valuesOptions." + valueName, depth + 1);
      }
    }
    if (entry.methods !== undefined) {
      const methods = object(entry.methods, location + ".methods");
      for (const [methodName, method] of Object.entries(methods)) {
        name(methodName, location + ".methods");
        const declaration = visit(
          method,
          location + ".methods." + methodName,
          depth + 1
        );
        reference(
          declaration.requestType,
          location + ".methods." + methodName + ".requestType"
        );
        reference(
          declaration.responseType,
          location + ".methods." + methodName + ".responseType"
        );
      }
    }
    if (entry.nested !== undefined) {
      const nested = object(entry.nested, location + ".nested");
      for (const [nestedName, child] of Object.entries(nested)) {
        name(nestedName, location + ".nested");
        visitNamespace(child, location + ".nested." + nestedName, depth + 1);
      }
    }
  }

  visitNamespace(value, "root", 0);
}
