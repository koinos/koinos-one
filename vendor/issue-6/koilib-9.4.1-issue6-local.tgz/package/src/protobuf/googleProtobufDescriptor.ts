export const googleProtobufDescriptor = {
  google: {
    nested: {
      protobuf: {
        options: {
          go_package: "google.golang.org/protobuf/types/descriptorpb",
          java_package: "com.google.protobuf",
          java_outer_classname: "DescriptorProtos",
          csharp_namespace: "Google.Protobuf.Reflection",
          objc_class_prefix: "GPB",
          cc_enable_arenas: true,
          optimize_for: "SPEED",
        },
        nested: {
          FileDescriptorSet: {
            fields: {
              file: {
                rule: "repeated",
                type: "FileDescriptorProto",
                id: 1,
              },
            },
          },
          FileDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              package: {
                type: "string",
                id: 2,
              },
              dependency: {
                rule: "repeated",
                type: "string",
                id: 3,
              },
              public_dependency: {
                rule: "repeated",
                type: "int32",
                id: 10,
                options: {
                  packed: false,
                },
              },
              weak_dependency: {
                rule: "repeated",
                type: "int32",
                id: 11,
                options: {
                  packed: false,
                },
              },
              message_type: {
                rule: "repeated",
                type: "DescriptorProto",
                id: 4,
              },
              enum_type: {
                rule: "repeated",
                type: "EnumDescriptorProto",
                id: 5,
              },
              service: {
                rule: "repeated",
                type: "ServiceDescriptorProto",
                id: 6,
              },
              extension: {
                rule: "repeated",
                type: "FieldDescriptorProto",
                id: 7,
              },
              options: {
                type: "FileOptions",
                id: 8,
              },
              source_code_info: {
                type: "SourceCodeInfo",
                id: 9,
              },
              syntax: {
                type: "string",
                id: 12,
              },
            },
          },
          DescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              field: {
                rule: "repeated",
                type: "FieldDescriptorProto",
                id: 2,
              },
              extension: {
                rule: "repeated",
                type: "FieldDescriptorProto",
                id: 6,
              },
              nested_type: {
                rule: "repeated",
                type: "DescriptorProto",
                id: 3,
              },
              enum_type: {
                rule: "repeated",
                type: "EnumDescriptorProto",
                id: 4,
              },
              extension_range: {
                rule: "repeated",
                type: "ExtensionRange",
                id: 5,
              },
              oneof_decl: {
                rule: "repeated",
                type: "OneofDescriptorProto",
                id: 8,
              },
              options: {
                type: "MessageOptions",
                id: 7,
              },
              reserved_range: {
                rule: "repeated",
                type: "ReservedRange",
                id: 9,
              },
              reserved_name: {
                rule: "repeated",
                type: "string",
                id: 10,
              },
            },
            nested: {
              ExtensionRange: {
                fields: {
                  start: {
                    type: "int32",
                    id: 1,
                  },
                  end: {
                    type: "int32",
                    id: 2,
                  },
                  options: {
                    type: "ExtensionRangeOptions",
                    id: 3,
                  },
                },
              },
              ReservedRange: {
                fields: {
                  start: {
                    type: "int32",
                    id: 1,
                  },
                  end: {
                    type: "int32",
                    id: 2,
                  },
                },
              },
            },
          },
          ExtensionRangeOptions: {
            fields: {
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
          },
          FieldDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              number: {
                type: "int32",
                id: 3,
              },
              label: {
                type: "Label",
                id: 4,
              },
              type: {
                type: "Type",
                id: 5,
              },
              type_name: {
                type: "string",
                id: 6,
              },
              extendee: {
                type: "string",
                id: 2,
              },
              default_value: {
                type: "string",
                id: 7,
              },
              oneof_index: {
                type: "int32",
                id: 9,
              },
              json_name: {
                type: "string",
                id: 10,
              },
              options: {
                type: "FieldOptions",
                id: 8,
              },
              proto3_optional: {
                type: "bool",
                id: 17,
              },
            },
            nested: {
              Type: {
                values: {
                  TYPE_DOUBLE: 1,
                  TYPE_FLOAT: 2,
                  TYPE_INT64: 3,
                  TYPE_UINT64: 4,
                  TYPE_INT32: 5,
                  TYPE_FIXED64: 6,
                  TYPE_FIXED32: 7,
                  TYPE_BOOL: 8,
                  TYPE_STRING: 9,
                  TYPE_GROUP: 10,
                  TYPE_MESSAGE: 11,
                  TYPE_BYTES: 12,
                  TYPE_UINT32: 13,
                  TYPE_ENUM: 14,
                  TYPE_SFIXED32: 15,
                  TYPE_SFIXED64: 16,
                  TYPE_SINT32: 17,
                  TYPE_SINT64: 18,
                },
              },
              Label: {
                values: {
                  LABEL_OPTIONAL: 1,
                  LABEL_REQUIRED: 2,
                  LABEL_REPEATED: 3,
                },
              },
            },
          },
          OneofDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              options: {
                type: "OneofOptions",
                id: 2,
              },
            },
          },
          EnumDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              value: {
                rule: "repeated",
                type: "EnumValueDescriptorProto",
                id: 2,
              },
              options: {
                type: "EnumOptions",
                id: 3,
              },
              reserved_range: {
                rule: "repeated",
                type: "EnumReservedRange",
                id: 4,
              },
              reserved_name: {
                rule: "repeated",
                type: "string",
                id: 5,
              },
            },
            nested: {
              EnumReservedRange: {
                fields: {
                  start: {
                    type: "int32",
                    id: 1,
                  },
                  end: {
                    type: "int32",
                    id: 2,
                  },
                },
              },
            },
          },
          EnumValueDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              number: {
                type: "int32",
                id: 2,
              },
              options: {
                type: "EnumValueOptions",
                id: 3,
              },
            },
          },
          ServiceDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              method: {
                rule: "repeated",
                type: "MethodDescriptorProto",
                id: 2,
              },
              options: {
                type: "ServiceOptions",
                id: 3,
              },
            },
          },
          MethodDescriptorProto: {
            fields: {
              name: {
                type: "string",
                id: 1,
              },
              input_type: {
                type: "string",
                id: 2,
              },
              output_type: {
                type: "string",
                id: 3,
              },
              options: {
                type: "MethodOptions",
                id: 4,
              },
              client_streaming: {
                type: "bool",
                id: 5,
                options: {
                  default: false,
                },
              },
              server_streaming: {
                type: "bool",
                id: 6,
                options: {
                  default: false,
                },
              },
            },
          },
          FileOptions: {
            fields: {
              java_package: {
                type: "string",
                id: 1,
              },
              java_outer_classname: {
                type: "string",
                id: 8,
              },
              java_multiple_files: {
                type: "bool",
                id: 10,
                options: {
                  default: false,
                },
              },
              java_generate_equals_and_hash: {
                type: "bool",
                id: 20,
                options: {
                  deprecated: true,
                },
              },
              java_string_check_utf8: {
                type: "bool",
                id: 27,
                options: {
                  default: false,
                },
              },
              optimize_for: {
                type: "OptimizeMode",
                id: 9,
                options: {
                  default: "SPEED",
                },
              },
              go_package: {
                type: "string",
                id: 11,
              },
              cc_generic_services: {
                type: "bool",
                id: 16,
                options: {
                  default: false,
                },
              },
              java_generic_services: {
                type: "bool",
                id: 17,
                options: {
                  default: false,
                },
              },
              py_generic_services: {
                type: "bool",
                id: 18,
                options: {
                  default: false,
                },
              },
              php_generic_services: {
                type: "bool",
                id: 42,
                options: {
                  default: false,
                },
              },
              deprecated: {
                type: "bool",
                id: 23,
                options: {
                  default: false,
                },
              },
              cc_enable_arenas: {
                type: "bool",
                id: 31,
                options: {
                  default: true,
                },
              },
              objc_class_prefix: {
                type: "string",
                id: 36,
              },
              csharp_namespace: {
                type: "string",
                id: 37,
              },
              swift_prefix: {
                type: "string",
                id: 39,
              },
              php_class_prefix: {
                type: "string",
                id: 40,
              },
              php_namespace: {
                type: "string",
                id: 41,
              },
              php_metadata_namespace: {
                type: "string",
                id: 44,
              },
              ruby_package: {
                type: "string",
                id: 45,
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
            reserved: [[38, 38]],
            nested: {
              OptimizeMode: {
                values: {
                  SPEED: 1,
                  CODE_SIZE: 2,
                  LITE_RUNTIME: 3,
                },
              },
            },
          },
          MessageOptions: {
            fields: {
              message_set_wire_format: {
                type: "bool",
                id: 1,
                options: {
                  default: false,
                },
              },
              no_standard_descriptor_accessor: {
                type: "bool",
                id: 2,
                options: {
                  default: false,
                },
              },
              deprecated: {
                type: "bool",
                id: 3,
                options: {
                  default: false,
                },
              },
              map_entry: {
                type: "bool",
                id: 7,
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
            reserved: [
              [4, 4],
              [5, 5],
              [6, 6],
              [8, 8],
              [9, 9],
            ],
          },
          FieldOptions: {
            fields: {
              ctype: {
                type: "CType",
                id: 1,
                options: {
                  default: "STRING",
                },
              },
              packed: {
                type: "bool",
                id: 2,
              },
              jstype: {
                type: "JSType",
                id: 6,
                options: {
                  default: "JS_NORMAL",
                },
              },
              lazy: {
                type: "bool",
                id: 5,
                options: {
                  default: false,
                },
              },
              deprecated: {
                type: "bool",
                id: 3,
                options: {
                  default: false,
                },
              },
              weak: {
                type: "bool",
                id: 10,
                options: {
                  default: false,
                },
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
            reserved: [[4, 4]],
            nested: {
              CType: {
                values: {
                  STRING: 0,
                  CORD: 1,
                  STRING_PIECE: 2,
                },
              },
              JSType: {
                values: {
                  JS_NORMAL: 0,
                  JS_STRING: 1,
                  JS_NUMBER: 2,
                },
              },
            },
          },
          OneofOptions: {
            fields: {
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
          },
          EnumOptions: {
            fields: {
              allow_alias: {
                type: "bool",
                id: 2,
              },
              deprecated: {
                type: "bool",
                id: 3,
                options: {
                  default: false,
                },
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
            reserved: [[5, 5]],
          },
          EnumValueOptions: {
            fields: {
              deprecated: {
                type: "bool",
                id: 1,
                options: {
                  default: false,
                },
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
          },
          ServiceOptions: {
            fields: {
              deprecated: {
                type: "bool",
                id: 33,
                options: {
                  default: false,
                },
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
          },
          MethodOptions: {
            fields: {
              deprecated: {
                type: "bool",
                id: 33,
                options: {
                  default: false,
                },
              },
              idempotency_level: {
                type: "IdempotencyLevel",
                id: 34,
                options: {
                  default: "IDEMPOTENCY_UNKNOWN",
                },
              },
              uninterpreted_option: {
                rule: "repeated",
                type: "UninterpretedOption",
                id: 999,
              },
            },
            extensions: [[1000, 536870911]],
            nested: {
              IdempotencyLevel: {
                values: {
                  IDEMPOTENCY_UNKNOWN: 0,
                  NO_SIDE_EFFECTS: 1,
                  IDEMPOTENT: 2,
                },
              },
            },
          },
          UninterpretedOption: {
            fields: {
              name: {
                rule: "repeated",
                type: "NamePart",
                id: 2,
              },
              identifier_value: {
                type: "string",
                id: 3,
              },
              positive_int_value: {
                type: "uint64",
                id: 4,
              },
              negative_int_value: {
                type: "int64",
                id: 5,
              },
              double_value: {
                type: "double",
                id: 6,
              },
              string_value: {
                type: "bytes",
                id: 7,
              },
              aggregate_value: {
                type: "string",
                id: 8,
              },
            },
            nested: {
              NamePart: {
                fields: {
                  name_part: {
                    rule: "required",
                    type: "string",
                    id: 1,
                  },
                  is_extension: {
                    rule: "required",
                    type: "bool",
                    id: 2,
                  },
                },
              },
            },
          },
          SourceCodeInfo: {
            fields: {
              location: {
                rule: "repeated",
                type: "Location",
                id: 1,
              },
            },
            nested: {
              Location: {
                fields: {
                  path: {
                    rule: "repeated",
                    type: "int32",
                    id: 1,
                  },
                  span: {
                    rule: "repeated",
                    type: "int32",
                    id: 2,
                  },
                  leading_comments: {
                    type: "string",
                    id: 3,
                  },
                  trailing_comments: {
                    type: "string",
                    id: 4,
                  },
                  leading_detached_comments: {
                    rule: "repeated",
                    type: "string",
                    id: 6,
                  },
                },
              },
            },
          },
          GeneratedCodeInfo: {
            fields: {
              annotation: {
                rule: "repeated",
                type: "Annotation",
                id: 1,
              },
            },
            nested: {
              Annotation: {
                fields: {
                  path: {
                    rule: "repeated",
                    type: "int32",
                    id: 1,
                  },
                  source_file: {
                    type: "string",
                    id: 2,
                  },
                  begin: {
                    type: "int32",
                    id: 3,
                  },
                  end: {
                    type: "int32",
                    id: 4,
                  },
                },
              },
            },
          },
        },
      },
    },
  },
};
