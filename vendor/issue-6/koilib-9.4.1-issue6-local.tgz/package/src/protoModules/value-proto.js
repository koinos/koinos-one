/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
(function(global, factory) { /* global define, require, module */

    /* AMD */ if (typeof define === 'function' && define.amd)
        define(["protobufjs/minimal"], factory);

    /* CommonJS */ else if (typeof require === 'function' && typeof module === 'object' && module && module.exports)
        module.exports = factory(require("protobufjs/minimal"));

})(this, function($protobuf) {
    "use strict";

    // Common aliases
    var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;
    
    // Exported root namespace
    var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});
    
    $root.koinos = (function() {
    
        /**
         * Namespace koinos.
         * @exports koinos
         * @namespace
         */
        var koinos = {};
    
        koinos.chain = (function() {
    
            /**
             * Namespace chain.
             * @memberof koinos
             * @namespace
             */
            var chain = {};
    
            chain.value_type = (function() {
    
                /**
                 * Properties of a value_type.
                 * @memberof koinos.chain
                 * @interface Ivalue_type
                 * @property {google.protobuf.IAny|null} [message_value] value_type message_value
                 * @property {number|null} [int32_value] value_type int32_value
                 * @property {number|Long|null} [int64_value] value_type int64_value
                 * @property {number|null} [uint32_value] value_type uint32_value
                 * @property {number|Long|null} [uint64_value] value_type uint64_value
                 * @property {number|null} [sint32_value] value_type sint32_value
                 * @property {number|Long|null} [sint64_value] value_type sint64_value
                 * @property {number|null} [fixed32_value] value_type fixed32_value
                 * @property {number|Long|null} [fixed64_value] value_type fixed64_value
                 * @property {number|null} [sfixed32_value] value_type sfixed32_value
                 * @property {number|Long|null} [sfixed64_value] value_type sfixed64_value
                 * @property {boolean|null} [bool_value] value_type bool_value
                 * @property {string|null} [string_value] value_type string_value
                 * @property {Uint8Array|null} [bytes_value] value_type bytes_value
                 */
    
                /**
                 * Constructs a new value_type.
                 * @memberof koinos.chain
                 * @classdesc Represents a value_type.
                 * @implements Ivalue_type
                 * @constructor
                 * @param {koinos.chain.Ivalue_type=} [properties] Properties to set
                 */
                function value_type(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null && keys[i] !== "__proto__")
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * value_type message_value.
                 * @member {google.protobuf.IAny|null|undefined} message_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.message_value = null;
    
                /**
                 * value_type int32_value.
                 * @member {number|null|undefined} int32_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.int32_value = null;
    
                /**
                 * value_type int64_value.
                 * @member {number|Long|null|undefined} int64_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.int64_value = null;
    
                /**
                 * value_type uint32_value.
                 * @member {number|null|undefined} uint32_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.uint32_value = null;
    
                /**
                 * value_type uint64_value.
                 * @member {number|Long|null|undefined} uint64_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.uint64_value = null;
    
                /**
                 * value_type sint32_value.
                 * @member {number|null|undefined} sint32_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.sint32_value = null;
    
                /**
                 * value_type sint64_value.
                 * @member {number|Long|null|undefined} sint64_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.sint64_value = null;
    
                /**
                 * value_type fixed32_value.
                 * @member {number|null|undefined} fixed32_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.fixed32_value = null;
    
                /**
                 * value_type fixed64_value.
                 * @member {number|Long|null|undefined} fixed64_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.fixed64_value = null;
    
                /**
                 * value_type sfixed32_value.
                 * @member {number|null|undefined} sfixed32_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.sfixed32_value = null;
    
                /**
                 * value_type sfixed64_value.
                 * @member {number|Long|null|undefined} sfixed64_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.sfixed64_value = null;
    
                /**
                 * value_type bool_value.
                 * @member {boolean|null|undefined} bool_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.bool_value = null;
    
                /**
                 * value_type string_value.
                 * @member {string|null|undefined} string_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.string_value = null;
    
                /**
                 * value_type bytes_value.
                 * @member {Uint8Array|null|undefined} bytes_value
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                value_type.prototype.bytes_value = null;
    
                // OneOf field names bound to virtual getters and setters
                var $oneOfFields;
    
                /**
                 * value_type kind.
                 * @member {"message_value"|"int32_value"|"int64_value"|"uint32_value"|"uint64_value"|"sint32_value"|"sint64_value"|"fixed32_value"|"fixed64_value"|"sfixed32_value"|"sfixed64_value"|"bool_value"|"string_value"|"bytes_value"|undefined} kind
                 * @memberof koinos.chain.value_type
                 * @instance
                 */
                Object.defineProperty(value_type.prototype, "kind", {
                    get: $util.oneOfGetter($oneOfFields = ["message_value", "int32_value", "int64_value", "uint32_value", "uint64_value", "sint32_value", "sint64_value", "fixed32_value", "fixed64_value", "sfixed32_value", "sfixed64_value", "bool_value", "string_value", "bytes_value"]),
                    set: $util.oneOfSetter($oneOfFields)
                });
    
                /**
                 * Creates a new value_type instance using the specified properties.
                 * @function create
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {koinos.chain.Ivalue_type=} [properties] Properties to set
                 * @returns {koinos.chain.value_type} value_type instance
                 */
                value_type.create = function create(properties) {
                    return new value_type(properties);
                };
    
                /**
                 * Encodes the specified value_type message. Does not implicitly {@link koinos.chain.value_type.verify|verify} messages.
                 * @function encode
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {koinos.chain.Ivalue_type} message value_type message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                value_type.encode = function encode(message, writer, q) {
                    if (!writer)
                        writer = $Writer.create();
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    if (message.message_value != null && Object.hasOwnProperty.call(message, "message_value"))
                        $root.google.protobuf.Any.encode(message.message_value, writer.uint32(/* id 1, wireType 2 =*/10).fork(), q + 1).ldelim();
                    if (message.int32_value != null && Object.hasOwnProperty.call(message, "int32_value"))
                        writer.uint32(/* id 2, wireType 0 =*/16).int32(message.int32_value);
                    if (message.int64_value != null && Object.hasOwnProperty.call(message, "int64_value"))
                        writer.uint32(/* id 3, wireType 0 =*/24).int64(message.int64_value);
                    if (message.uint32_value != null && Object.hasOwnProperty.call(message, "uint32_value"))
                        writer.uint32(/* id 4, wireType 0 =*/32).uint32(message.uint32_value);
                    if (message.uint64_value != null && Object.hasOwnProperty.call(message, "uint64_value"))
                        writer.uint32(/* id 5, wireType 0 =*/40).uint64(message.uint64_value);
                    if (message.sint32_value != null && Object.hasOwnProperty.call(message, "sint32_value"))
                        writer.uint32(/* id 6, wireType 0 =*/48).sint32(message.sint32_value);
                    if (message.sint64_value != null && Object.hasOwnProperty.call(message, "sint64_value"))
                        writer.uint32(/* id 7, wireType 0 =*/56).sint64(message.sint64_value);
                    if (message.fixed32_value != null && Object.hasOwnProperty.call(message, "fixed32_value"))
                        writer.uint32(/* id 8, wireType 5 =*/69).fixed32(message.fixed32_value);
                    if (message.fixed64_value != null && Object.hasOwnProperty.call(message, "fixed64_value"))
                        writer.uint32(/* id 9, wireType 1 =*/73).fixed64(message.fixed64_value);
                    if (message.sfixed32_value != null && Object.hasOwnProperty.call(message, "sfixed32_value"))
                        writer.uint32(/* id 10, wireType 5 =*/85).sfixed32(message.sfixed32_value);
                    if (message.sfixed64_value != null && Object.hasOwnProperty.call(message, "sfixed64_value"))
                        writer.uint32(/* id 11, wireType 1 =*/89).sfixed64(message.sfixed64_value);
                    if (message.bool_value != null && Object.hasOwnProperty.call(message, "bool_value"))
                        writer.uint32(/* id 12, wireType 0 =*/96).bool(message.bool_value);
                    if (message.string_value != null && Object.hasOwnProperty.call(message, "string_value"))
                        writer.uint32(/* id 13, wireType 2 =*/106).string(message.string_value);
                    if (message.bytes_value != null && Object.hasOwnProperty.call(message, "bytes_value"))
                        writer.uint32(/* id 14, wireType 2 =*/114).bytes(message.bytes_value);
                    return writer;
                };
    
                /**
                 * Encodes the specified value_type message, length delimited. Does not implicitly {@link koinos.chain.value_type.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {koinos.chain.Ivalue_type} message value_type message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                value_type.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a value_type message from the specified reader or buffer.
                 * @function decode
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {koinos.chain.value_type} value_type
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                value_type.decode = function decode(reader, length, error, long) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    if (long === undefined)
                        long = 0;
                    if (long > $Reader.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var end, message;
                    if (length === undefined)
                        end = reader.len;
                    else {
                        end = reader.pos + length;
                        if (end > reader.len)
                            throw RangeError("index out of range");
                        length = reader.len;
                        reader.len = end;
                    }
                    message = new $root.koinos.chain.value_type();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        if (tag === error)
                            break;
                        switch (tag >>> 3) {
                        case 1: {
                                message.message_value = $root.google.protobuf.Any.decode(reader, reader.uint32(), undefined, long + 1);
                                break;
                            }
                        case 2: {
                                message.int32_value = reader.int32();
                                break;
                            }
                        case 3: {
                                message.int64_value = reader.int64();
                                break;
                            }
                        case 4: {
                                message.uint32_value = reader.uint32();
                                break;
                            }
                        case 5: {
                                message.uint64_value = reader.uint64();
                                break;
                            }
                        case 6: {
                                message.sint32_value = reader.sint32();
                                break;
                            }
                        case 7: {
                                message.sint64_value = reader.sint64();
                                break;
                            }
                        case 8: {
                                message.fixed32_value = reader.fixed32();
                                break;
                            }
                        case 9: {
                                message.fixed64_value = reader.fixed64();
                                break;
                            }
                        case 10: {
                                message.sfixed32_value = reader.sfixed32();
                                break;
                            }
                        case 11: {
                                message.sfixed64_value = reader.sfixed64();
                                break;
                            }
                        case 12: {
                                message.bool_value = reader.bool();
                                break;
                            }
                        case 13: {
                                message.string_value = reader.string();
                                break;
                            }
                        case 14: {
                                message.bytes_value = reader.bytes();
                                break;
                            }
                        default:
                            reader.skipType(tag & 7, long);
                            break;
                        }
                    }
                    if (length !== undefined) {
                        if (reader.pos !== end)
                            throw RangeError("index out of range");
                        reader.len = length;
                    }
                    return message;
                };
    
                /**
                 * Decodes a value_type message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {koinos.chain.value_type} value_type
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                value_type.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a value_type message.
                 * @function verify
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                value_type.verify = function verify(message, long) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        return "maximum nesting depth exceeded";
                    var properties = {};
                    if (message.message_value != null && Object.hasOwnProperty.call(message, "message_value")) {
                        properties.kind = 1;
                        {
                            var error = $root.google.protobuf.Any.verify(message.message_value, long + 1);
                            if (error)
                                return "message_value." + error;
                        }
                    }
                    if (message.int32_value != null && Object.hasOwnProperty.call(message, "int32_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.int32_value))
                            return "int32_value: integer expected";
                    }
                    if (message.int64_value != null && Object.hasOwnProperty.call(message, "int64_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.int64_value) && !(message.int64_value && $util.isInteger(message.int64_value.low) && $util.isInteger(message.int64_value.high)))
                            return "int64_value: integer|Long expected";
                    }
                    if (message.uint32_value != null && Object.hasOwnProperty.call(message, "uint32_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.uint32_value))
                            return "uint32_value: integer expected";
                    }
                    if (message.uint64_value != null && Object.hasOwnProperty.call(message, "uint64_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.uint64_value) && !(message.uint64_value && $util.isInteger(message.uint64_value.low) && $util.isInteger(message.uint64_value.high)))
                            return "uint64_value: integer|Long expected";
                    }
                    if (message.sint32_value != null && Object.hasOwnProperty.call(message, "sint32_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.sint32_value))
                            return "sint32_value: integer expected";
                    }
                    if (message.sint64_value != null && Object.hasOwnProperty.call(message, "sint64_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.sint64_value) && !(message.sint64_value && $util.isInteger(message.sint64_value.low) && $util.isInteger(message.sint64_value.high)))
                            return "sint64_value: integer|Long expected";
                    }
                    if (message.fixed32_value != null && Object.hasOwnProperty.call(message, "fixed32_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.fixed32_value))
                            return "fixed32_value: integer expected";
                    }
                    if (message.fixed64_value != null && Object.hasOwnProperty.call(message, "fixed64_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.fixed64_value) && !(message.fixed64_value && $util.isInteger(message.fixed64_value.low) && $util.isInteger(message.fixed64_value.high)))
                            return "fixed64_value: integer|Long expected";
                    }
                    if (message.sfixed32_value != null && Object.hasOwnProperty.call(message, "sfixed32_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.sfixed32_value))
                            return "sfixed32_value: integer expected";
                    }
                    if (message.sfixed64_value != null && Object.hasOwnProperty.call(message, "sfixed64_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isInteger(message.sfixed64_value) && !(message.sfixed64_value && $util.isInteger(message.sfixed64_value.low) && $util.isInteger(message.sfixed64_value.high)))
                            return "sfixed64_value: integer|Long expected";
                    }
                    if (message.bool_value != null && Object.hasOwnProperty.call(message, "bool_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (typeof message.bool_value !== "boolean")
                            return "bool_value: boolean expected";
                    }
                    if (message.string_value != null && Object.hasOwnProperty.call(message, "string_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!$util.isString(message.string_value))
                            return "string_value: string expected";
                    }
                    if (message.bytes_value != null && Object.hasOwnProperty.call(message, "bytes_value")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        if (!(message.bytes_value && typeof message.bytes_value.length === "number" || $util.isString(message.bytes_value)))
                            return "bytes_value: buffer expected";
                    }
                    return null;
                };
    
                /**
                 * Creates a value_type message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {koinos.chain.value_type} value_type
                 */
                value_type.fromObject = function fromObject(object, long) {
                    if (object instanceof $root.koinos.chain.value_type)
                        return object;
                    if (!$util.isObject(object))
                        throw TypeError(".koinos.chain.value_type: object expected");
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var message = new $root.koinos.chain.value_type();
                    if (object.message_value != null) {
                        if (!$util.isObject(object.message_value))
                            throw TypeError(".koinos.chain.value_type.message_value: object expected");
                        message.message_value = $root.google.protobuf.Any.fromObject(object.message_value, long + 1);
                    }
                    if (object.int32_value != null)
                        message.int32_value = object.int32_value | 0;
                    if (object.int64_value != null)
                        if ($util.Long)
                            message.int64_value = $util.Long.fromValue(object.int64_value, false);
                        else if (typeof object.int64_value === "string")
                            message.int64_value = parseInt(object.int64_value, 10);
                        else if (typeof object.int64_value === "number")
                            message.int64_value = object.int64_value;
                        else if (typeof object.int64_value === "object")
                            message.int64_value = new $util.LongBits(object.int64_value.low >>> 0, object.int64_value.high >>> 0).toNumber();
                    if (object.uint32_value != null)
                        message.uint32_value = object.uint32_value >>> 0;
                    if (object.uint64_value != null)
                        if ($util.Long)
                            message.uint64_value = $util.Long.fromValue(object.uint64_value, true);
                        else if (typeof object.uint64_value === "string")
                            message.uint64_value = parseInt(object.uint64_value, 10);
                        else if (typeof object.uint64_value === "number")
                            message.uint64_value = object.uint64_value;
                        else if (typeof object.uint64_value === "object")
                            message.uint64_value = new $util.LongBits(object.uint64_value.low >>> 0, object.uint64_value.high >>> 0).toNumber(true);
                    if (object.sint32_value != null)
                        message.sint32_value = object.sint32_value | 0;
                    if (object.sint64_value != null)
                        if ($util.Long)
                            message.sint64_value = $util.Long.fromValue(object.sint64_value, false);
                        else if (typeof object.sint64_value === "string")
                            message.sint64_value = parseInt(object.sint64_value, 10);
                        else if (typeof object.sint64_value === "number")
                            message.sint64_value = object.sint64_value;
                        else if (typeof object.sint64_value === "object")
                            message.sint64_value = new $util.LongBits(object.sint64_value.low >>> 0, object.sint64_value.high >>> 0).toNumber();
                    if (object.fixed32_value != null)
                        message.fixed32_value = object.fixed32_value >>> 0;
                    if (object.fixed64_value != null)
                        if ($util.Long)
                            message.fixed64_value = $util.Long.fromValue(object.fixed64_value, true);
                        else if (typeof object.fixed64_value === "string")
                            message.fixed64_value = parseInt(object.fixed64_value, 10);
                        else if (typeof object.fixed64_value === "number")
                            message.fixed64_value = object.fixed64_value;
                        else if (typeof object.fixed64_value === "object")
                            message.fixed64_value = new $util.LongBits(object.fixed64_value.low >>> 0, object.fixed64_value.high >>> 0).toNumber(true);
                    if (object.sfixed32_value != null)
                        message.sfixed32_value = object.sfixed32_value | 0;
                    if (object.sfixed64_value != null)
                        if ($util.Long)
                            message.sfixed64_value = $util.Long.fromValue(object.sfixed64_value, false);
                        else if (typeof object.sfixed64_value === "string")
                            message.sfixed64_value = parseInt(object.sfixed64_value, 10);
                        else if (typeof object.sfixed64_value === "number")
                            message.sfixed64_value = object.sfixed64_value;
                        else if (typeof object.sfixed64_value === "object")
                            message.sfixed64_value = new $util.LongBits(object.sfixed64_value.low >>> 0, object.sfixed64_value.high >>> 0).toNumber();
                    if (object.bool_value != null)
                        message.bool_value = Boolean(object.bool_value);
                    if (object.string_value != null)
                        message.string_value = String(object.string_value);
                    if (object.bytes_value != null)
                        if (typeof object.bytes_value === "string")
                            $util.base64.decode(object.bytes_value, message.bytes_value = $util.newBuffer($util.base64.length(object.bytes_value)), 0);
                        else if (object.bytes_value.length >= 0)
                            message.bytes_value = object.bytes_value;
                    return message;
                };
    
                /**
                 * Creates a plain object from a value_type message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {koinos.chain.value_type} message value_type
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                value_type.toObject = function toObject(message, options, q) {
                    if (!options)
                        options = {};
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    var object = {};
                    if (message.message_value != null && Object.hasOwnProperty.call(message, "message_value")) {
                        object.message_value = $root.google.protobuf.Any.toObject(message.message_value, options, q + 1);
                        if (options.oneofs)
                            object.kind = "message_value";
                    }
                    if (message.int32_value != null && Object.hasOwnProperty.call(message, "int32_value")) {
                        object.int32_value = message.int32_value;
                        if (options.oneofs)
                            object.kind = "int32_value";
                    }
                    if (message.int64_value != null && Object.hasOwnProperty.call(message, "int64_value")) {
                        if (typeof BigInt !== "undefined" && options.longs === BigInt)
                            object.int64_value = typeof message.int64_value === "number" ? BigInt(message.int64_value) : $util.Long.fromBits(message.int64_value.low >>> 0, message.int64_value.high >>> 0, false).toBigInt();
                        else if (typeof message.int64_value === "number")
                            object.int64_value = options.longs === String ? String(message.int64_value) : message.int64_value;
                        else
                            object.int64_value = options.longs === String ? $util.Long.prototype.toString.call(message.int64_value) : options.longs === Number ? new $util.LongBits(message.int64_value.low >>> 0, message.int64_value.high >>> 0).toNumber() : message.int64_value;
                        if (options.oneofs)
                            object.kind = "int64_value";
                    }
                    if (message.uint32_value != null && Object.hasOwnProperty.call(message, "uint32_value")) {
                        object.uint32_value = message.uint32_value;
                        if (options.oneofs)
                            object.kind = "uint32_value";
                    }
                    if (message.uint64_value != null && Object.hasOwnProperty.call(message, "uint64_value")) {
                        if (typeof BigInt !== "undefined" && options.longs === BigInt)
                            object.uint64_value = typeof message.uint64_value === "number" ? BigInt(message.uint64_value) : $util.Long.fromBits(message.uint64_value.low >>> 0, message.uint64_value.high >>> 0, true).toBigInt();
                        else if (typeof message.uint64_value === "number")
                            object.uint64_value = options.longs === String ? String(message.uint64_value) : message.uint64_value;
                        else
                            object.uint64_value = options.longs === String ? $util.Long.prototype.toString.call(message.uint64_value) : options.longs === Number ? new $util.LongBits(message.uint64_value.low >>> 0, message.uint64_value.high >>> 0).toNumber(true) : message.uint64_value;
                        if (options.oneofs)
                            object.kind = "uint64_value";
                    }
                    if (message.sint32_value != null && Object.hasOwnProperty.call(message, "sint32_value")) {
                        object.sint32_value = message.sint32_value;
                        if (options.oneofs)
                            object.kind = "sint32_value";
                    }
                    if (message.sint64_value != null && Object.hasOwnProperty.call(message, "sint64_value")) {
                        if (typeof BigInt !== "undefined" && options.longs === BigInt)
                            object.sint64_value = typeof message.sint64_value === "number" ? BigInt(message.sint64_value) : $util.Long.fromBits(message.sint64_value.low >>> 0, message.sint64_value.high >>> 0, false).toBigInt();
                        else if (typeof message.sint64_value === "number")
                            object.sint64_value = options.longs === String ? String(message.sint64_value) : message.sint64_value;
                        else
                            object.sint64_value = options.longs === String ? $util.Long.prototype.toString.call(message.sint64_value) : options.longs === Number ? new $util.LongBits(message.sint64_value.low >>> 0, message.sint64_value.high >>> 0).toNumber() : message.sint64_value;
                        if (options.oneofs)
                            object.kind = "sint64_value";
                    }
                    if (message.fixed32_value != null && Object.hasOwnProperty.call(message, "fixed32_value")) {
                        object.fixed32_value = message.fixed32_value;
                        if (options.oneofs)
                            object.kind = "fixed32_value";
                    }
                    if (message.fixed64_value != null && Object.hasOwnProperty.call(message, "fixed64_value")) {
                        if (typeof BigInt !== "undefined" && options.longs === BigInt)
                            object.fixed64_value = typeof message.fixed64_value === "number" ? BigInt(message.fixed64_value) : $util.Long.fromBits(message.fixed64_value.low >>> 0, message.fixed64_value.high >>> 0, true).toBigInt();
                        else if (typeof message.fixed64_value === "number")
                            object.fixed64_value = options.longs === String ? String(message.fixed64_value) : message.fixed64_value;
                        else
                            object.fixed64_value = options.longs === String ? $util.Long.prototype.toString.call(message.fixed64_value) : options.longs === Number ? new $util.LongBits(message.fixed64_value.low >>> 0, message.fixed64_value.high >>> 0).toNumber(true) : message.fixed64_value;
                        if (options.oneofs)
                            object.kind = "fixed64_value";
                    }
                    if (message.sfixed32_value != null && Object.hasOwnProperty.call(message, "sfixed32_value")) {
                        object.sfixed32_value = message.sfixed32_value;
                        if (options.oneofs)
                            object.kind = "sfixed32_value";
                    }
                    if (message.sfixed64_value != null && Object.hasOwnProperty.call(message, "sfixed64_value")) {
                        if (typeof BigInt !== "undefined" && options.longs === BigInt)
                            object.sfixed64_value = typeof message.sfixed64_value === "number" ? BigInt(message.sfixed64_value) : $util.Long.fromBits(message.sfixed64_value.low >>> 0, message.sfixed64_value.high >>> 0, false).toBigInt();
                        else if (typeof message.sfixed64_value === "number")
                            object.sfixed64_value = options.longs === String ? String(message.sfixed64_value) : message.sfixed64_value;
                        else
                            object.sfixed64_value = options.longs === String ? $util.Long.prototype.toString.call(message.sfixed64_value) : options.longs === Number ? new $util.LongBits(message.sfixed64_value.low >>> 0, message.sfixed64_value.high >>> 0).toNumber() : message.sfixed64_value;
                        if (options.oneofs)
                            object.kind = "sfixed64_value";
                    }
                    if (message.bool_value != null && Object.hasOwnProperty.call(message, "bool_value")) {
                        object.bool_value = message.bool_value;
                        if (options.oneofs)
                            object.kind = "bool_value";
                    }
                    if (message.string_value != null && Object.hasOwnProperty.call(message, "string_value")) {
                        object.string_value = message.string_value;
                        if (options.oneofs)
                            object.kind = "string_value";
                    }
                    if (message.bytes_value != null && Object.hasOwnProperty.call(message, "bytes_value")) {
                        object.bytes_value = options.bytes === String ? $util.base64.encode(message.bytes_value, 0, message.bytes_value.length) : options.bytes === Array ? Array.prototype.slice.call(message.bytes_value) : message.bytes_value;
                        if (options.oneofs)
                            object.kind = "bytes_value";
                    }
                    return object;
                };
    
                /**
                 * Converts this value_type to JSON.
                 * @function toJSON
                 * @memberof koinos.chain.value_type
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                value_type.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                /**
                 * Gets the default type url for value_type
                 * @function getTypeUrl
                 * @memberof koinos.chain.value_type
                 * @static
                 * @param {string} [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
                 * @returns {string} The default type url
                 */
                value_type.getTypeUrl = function getTypeUrl(typeUrlPrefix) {
                    if (typeUrlPrefix === undefined) {
                        typeUrlPrefix = "type.googleapis.com";
                    }
                    return typeUrlPrefix + "/koinos.chain.value_type";
                };
    
                return value_type;
            })();
    
            chain.enum_type = (function() {
    
                /**
                 * Properties of an enum_type.
                 * @memberof koinos.chain
                 * @interface Ienum_type
                 * @property {string|null} [name] enum_type name
                 * @property {number|null} [number] enum_type number
                 */
    
                /**
                 * Constructs a new enum_type.
                 * @memberof koinos.chain
                 * @classdesc Represents an enum_type.
                 * @implements Ienum_type
                 * @constructor
                 * @param {koinos.chain.Ienum_type=} [properties] Properties to set
                 */
                function enum_type(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null && keys[i] !== "__proto__")
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * enum_type name.
                 * @member {string} name
                 * @memberof koinos.chain.enum_type
                 * @instance
                 */
                enum_type.prototype.name = "";
    
                /**
                 * enum_type number.
                 * @member {number} number
                 * @memberof koinos.chain.enum_type
                 * @instance
                 */
                enum_type.prototype.number = 0;
    
                /**
                 * Creates a new enum_type instance using the specified properties.
                 * @function create
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {koinos.chain.Ienum_type=} [properties] Properties to set
                 * @returns {koinos.chain.enum_type} enum_type instance
                 */
                enum_type.create = function create(properties) {
                    return new enum_type(properties);
                };
    
                /**
                 * Encodes the specified enum_type message. Does not implicitly {@link koinos.chain.enum_type.verify|verify} messages.
                 * @function encode
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {koinos.chain.Ienum_type} message enum_type message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                enum_type.encode = function encode(message, writer, q) {
                    if (!writer)
                        writer = $Writer.create();
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    if (message.name != null && Object.hasOwnProperty.call(message, "name"))
                        writer.uint32(/* id 1, wireType 2 =*/10).string(message.name);
                    if (message.number != null && Object.hasOwnProperty.call(message, "number"))
                        writer.uint32(/* id 2, wireType 0 =*/16).int32(message.number);
                    return writer;
                };
    
                /**
                 * Encodes the specified enum_type message, length delimited. Does not implicitly {@link koinos.chain.enum_type.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {koinos.chain.Ienum_type} message enum_type message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                enum_type.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an enum_type message from the specified reader or buffer.
                 * @function decode
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {koinos.chain.enum_type} enum_type
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                enum_type.decode = function decode(reader, length, error, long) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    if (long === undefined)
                        long = 0;
                    if (long > $Reader.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var end, message;
                    if (length === undefined)
                        end = reader.len;
                    else {
                        end = reader.pos + length;
                        if (end > reader.len)
                            throw RangeError("index out of range");
                        length = reader.len;
                        reader.len = end;
                    }
                    message = new $root.koinos.chain.enum_type();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        if (tag === error)
                            break;
                        switch (tag >>> 3) {
                        case 1: {
                                message.name = reader.string();
                                break;
                            }
                        case 2: {
                                message.number = reader.int32();
                                break;
                            }
                        default:
                            reader.skipType(tag & 7, long);
                            break;
                        }
                    }
                    if (length !== undefined) {
                        if (reader.pos !== end)
                            throw RangeError("index out of range");
                        reader.len = length;
                    }
                    return message;
                };
    
                /**
                 * Decodes an enum_type message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {koinos.chain.enum_type} enum_type
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                enum_type.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an enum_type message.
                 * @function verify
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                enum_type.verify = function verify(message, long) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        return "maximum nesting depth exceeded";
                    if (message.name != null && Object.hasOwnProperty.call(message, "name"))
                        if (!$util.isString(message.name))
                            return "name: string expected";
                    if (message.number != null && Object.hasOwnProperty.call(message, "number"))
                        if (!$util.isInteger(message.number))
                            return "number: integer expected";
                    return null;
                };
    
                /**
                 * Creates an enum_type message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {koinos.chain.enum_type} enum_type
                 */
                enum_type.fromObject = function fromObject(object, long) {
                    if (object instanceof $root.koinos.chain.enum_type)
                        return object;
                    if (!$util.isObject(object))
                        throw TypeError(".koinos.chain.enum_type: object expected");
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var message = new $root.koinos.chain.enum_type();
                    if (object.name != null)
                        message.name = String(object.name);
                    if (object.number != null)
                        message.number = object.number | 0;
                    return message;
                };
    
                /**
                 * Creates a plain object from an enum_type message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {koinos.chain.enum_type} message enum_type
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                enum_type.toObject = function toObject(message, options, q) {
                    if (!options)
                        options = {};
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    var object = {};
                    if (options.defaults) {
                        object.name = "";
                        object.number = 0;
                    }
                    if (message.name != null && Object.hasOwnProperty.call(message, "name"))
                        object.name = message.name;
                    if (message.number != null && Object.hasOwnProperty.call(message, "number"))
                        object.number = message.number;
                    return object;
                };
    
                /**
                 * Converts this enum_type to JSON.
                 * @function toJSON
                 * @memberof koinos.chain.enum_type
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                enum_type.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                /**
                 * Gets the default type url for enum_type
                 * @function getTypeUrl
                 * @memberof koinos.chain.enum_type
                 * @static
                 * @param {string} [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
                 * @returns {string} The default type url
                 */
                enum_type.getTypeUrl = function getTypeUrl(typeUrlPrefix) {
                    if (typeUrlPrefix === undefined) {
                        typeUrlPrefix = "type.googleapis.com";
                    }
                    return typeUrlPrefix + "/koinos.chain.enum_type";
                };
    
                return enum_type;
            })();
    
            chain.list_type = (function() {
    
                /**
                 * Properties of a list_type.
                 * @memberof koinos.chain
                 * @interface Ilist_type
                 * @property {Array.<koinos.chain.Ivalue_type>|null} [values] list_type values
                 */
    
                /**
                 * Constructs a new list_type.
                 * @memberof koinos.chain
                 * @classdesc Represents a list_type.
                 * @implements Ilist_type
                 * @constructor
                 * @param {koinos.chain.Ilist_type=} [properties] Properties to set
                 */
                function list_type(properties) {
                    this.values = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null && keys[i] !== "__proto__")
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * list_type values.
                 * @member {Array.<koinos.chain.Ivalue_type>} values
                 * @memberof koinos.chain.list_type
                 * @instance
                 */
                list_type.prototype.values = $util.emptyArray;
    
                /**
                 * Creates a new list_type instance using the specified properties.
                 * @function create
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {koinos.chain.Ilist_type=} [properties] Properties to set
                 * @returns {koinos.chain.list_type} list_type instance
                 */
                list_type.create = function create(properties) {
                    return new list_type(properties);
                };
    
                /**
                 * Encodes the specified list_type message. Does not implicitly {@link koinos.chain.list_type.verify|verify} messages.
                 * @function encode
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {koinos.chain.Ilist_type} message list_type message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                list_type.encode = function encode(message, writer, q) {
                    if (!writer)
                        writer = $Writer.create();
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    if (message.values != null && message.values.length)
                        for (var i = 0; i < message.values.length; ++i)
                            $root.koinos.chain.value_type.encode(message.values[i], writer.uint32(/* id 1, wireType 2 =*/10).fork(), q + 1).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified list_type message, length delimited. Does not implicitly {@link koinos.chain.list_type.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {koinos.chain.Ilist_type} message list_type message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                list_type.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a list_type message from the specified reader or buffer.
                 * @function decode
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {koinos.chain.list_type} list_type
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                list_type.decode = function decode(reader, length, error, long) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    if (long === undefined)
                        long = 0;
                    if (long > $Reader.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var end, message;
                    if (length === undefined)
                        end = reader.len;
                    else {
                        end = reader.pos + length;
                        if (end > reader.len)
                            throw RangeError("index out of range");
                        length = reader.len;
                        reader.len = end;
                    }
                    message = new $root.koinos.chain.list_type();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        if (tag === error)
                            break;
                        switch (tag >>> 3) {
                        case 1: {
                                if (!(message.values && message.values.length))
                                    message.values = [];
                                message.values.push($root.koinos.chain.value_type.decode(reader, reader.uint32(), undefined, long + 1));
                                break;
                            }
                        default:
                            reader.skipType(tag & 7, long);
                            break;
                        }
                    }
                    if (length !== undefined) {
                        if (reader.pos !== end)
                            throw RangeError("index out of range");
                        reader.len = length;
                    }
                    return message;
                };
    
                /**
                 * Decodes a list_type message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {koinos.chain.list_type} list_type
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                list_type.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a list_type message.
                 * @function verify
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                list_type.verify = function verify(message, long) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        return "maximum nesting depth exceeded";
                    if (message.values != null && Object.hasOwnProperty.call(message, "values")) {
                        if (!Array.isArray(message.values))
                            return "values: array expected";
                        for (var i = 0; i < message.values.length; ++i) {
                            var error = $root.koinos.chain.value_type.verify(message.values[i], long + 1);
                            if (error)
                                return "values." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a list_type message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {koinos.chain.list_type} list_type
                 */
                list_type.fromObject = function fromObject(object, long) {
                    if (object instanceof $root.koinos.chain.list_type)
                        return object;
                    if (!$util.isObject(object))
                        throw TypeError(".koinos.chain.list_type: object expected");
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var message = new $root.koinos.chain.list_type();
                    if (object.values) {
                        if (!Array.isArray(object.values))
                            throw TypeError(".koinos.chain.list_type.values: array expected");
                        message.values = [];
                        for (var i = 0; i < object.values.length; ++i) {
                            if (!$util.isObject(object.values[i]))
                                throw TypeError(".koinos.chain.list_type.values: object expected");
                            message.values[i] = $root.koinos.chain.value_type.fromObject(object.values[i], long + 1);
                        }
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a list_type message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {koinos.chain.list_type} message list_type
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                list_type.toObject = function toObject(message, options, q) {
                    if (!options)
                        options = {};
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.values = [];
                    if (message.values && message.values.length) {
                        object.values = [];
                        for (var j = 0; j < message.values.length; ++j)
                            object.values[j] = $root.koinos.chain.value_type.toObject(message.values[j], options, q + 1);
                    }
                    return object;
                };
    
                /**
                 * Converts this list_type to JSON.
                 * @function toJSON
                 * @memberof koinos.chain.list_type
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                list_type.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                /**
                 * Gets the default type url for list_type
                 * @function getTypeUrl
                 * @memberof koinos.chain.list_type
                 * @static
                 * @param {string} [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
                 * @returns {string} The default type url
                 */
                list_type.getTypeUrl = function getTypeUrl(typeUrlPrefix) {
                    if (typeUrlPrefix === undefined) {
                        typeUrlPrefix = "type.googleapis.com";
                    }
                    return typeUrlPrefix + "/koinos.chain.list_type";
                };
    
                return list_type;
            })();
    
            return chain;
        })();
    
        return koinos;
    })();
    
    $root.google = (function() {
    
        /**
         * Namespace google.
         * @exports google
         * @namespace
         */
        var google = {};
    
        google.protobuf = (function() {
    
            /**
             * Namespace protobuf.
             * @memberof google
             * @namespace
             */
            var protobuf = {};
    
            protobuf.Any = (function() {
    
                /**
                 * Properties of an Any.
                 * @memberof google.protobuf
                 * @interface IAny
                 * @property {string|null} [type_url] Any type_url
                 * @property {Uint8Array|null} [value] Any value
                 */
    
                /**
                 * Constructs a new Any.
                 * @memberof google.protobuf
                 * @classdesc Represents an Any.
                 * @implements IAny
                 * @constructor
                 * @param {google.protobuf.IAny=} [properties] Properties to set
                 */
                function Any(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null && keys[i] !== "__proto__")
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Any type_url.
                 * @member {string} type_url
                 * @memberof google.protobuf.Any
                 * @instance
                 */
                Any.prototype.type_url = "";
    
                /**
                 * Any value.
                 * @member {Uint8Array} value
                 * @memberof google.protobuf.Any
                 * @instance
                 */
                Any.prototype.value = $util.newBuffer([]);
    
                /**
                 * Creates a new Any instance using the specified properties.
                 * @function create
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {google.protobuf.IAny=} [properties] Properties to set
                 * @returns {google.protobuf.Any} Any instance
                 */
                Any.create = function create(properties) {
                    return new Any(properties);
                };
    
                /**
                 * Encodes the specified Any message. Does not implicitly {@link google.protobuf.Any.verify|verify} messages.
                 * @function encode
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {google.protobuf.IAny} message Any message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Any.encode = function encode(message, writer, q) {
                    if (!writer)
                        writer = $Writer.create();
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    if (message.type_url != null && Object.hasOwnProperty.call(message, "type_url"))
                        writer.uint32(/* id 1, wireType 2 =*/10).string(message.type_url);
                    if (message.value != null && Object.hasOwnProperty.call(message, "value"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.value);
                    return writer;
                };
    
                /**
                 * Encodes the specified Any message, length delimited. Does not implicitly {@link google.protobuf.Any.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {google.protobuf.IAny} message Any message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Any.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an Any message from the specified reader or buffer.
                 * @function decode
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {google.protobuf.Any} Any
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Any.decode = function decode(reader, length, error, long) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    if (long === undefined)
                        long = 0;
                    if (long > $Reader.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var end, message;
                    if (length === undefined)
                        end = reader.len;
                    else {
                        end = reader.pos + length;
                        if (end > reader.len)
                            throw RangeError("index out of range");
                        length = reader.len;
                        reader.len = end;
                    }
                    message = new $root.google.protobuf.Any();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        if (tag === error)
                            break;
                        switch (tag >>> 3) {
                        case 1: {
                                message.type_url = reader.string();
                                break;
                            }
                        case 2: {
                                message.value = reader.bytes();
                                break;
                            }
                        default:
                            reader.skipType(tag & 7, long);
                            break;
                        }
                    }
                    if (length !== undefined) {
                        if (reader.pos !== end)
                            throw RangeError("index out of range");
                        reader.len = length;
                    }
                    return message;
                };
    
                /**
                 * Decodes an Any message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {google.protobuf.Any} Any
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Any.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an Any message.
                 * @function verify
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Any.verify = function verify(message, long) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        return "maximum nesting depth exceeded";
                    if (message.type_url != null && Object.hasOwnProperty.call(message, "type_url"))
                        if (!$util.isString(message.type_url))
                            return "type_url: string expected";
                    if (message.value != null && Object.hasOwnProperty.call(message, "value"))
                        if (!(message.value && typeof message.value.length === "number" || $util.isString(message.value)))
                            return "value: buffer expected";
                    return null;
                };
    
                /**
                 * Creates an Any message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {google.protobuf.Any} Any
                 */
                Any.fromObject = function fromObject(object, long) {
                    if (object instanceof $root.google.protobuf.Any)
                        return object;
                    if (!$util.isObject(object))
                        throw TypeError(".google.protobuf.Any: object expected");
                    if (long === undefined)
                        long = 0;
                    if (long > $util.recursionLimit)
                        throw Error("maximum nesting depth exceeded");
                    var message = new $root.google.protobuf.Any();
                    if (object.type_url != null)
                        message.type_url = String(object.type_url);
                    if (object.value != null)
                        if (typeof object.value === "string")
                            $util.base64.decode(object.value, message.value = $util.newBuffer($util.base64.length(object.value)), 0);
                        else if (object.value.length >= 0)
                            message.value = object.value;
                    return message;
                };
    
                /**
                 * Creates a plain object from an Any message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {google.protobuf.Any} message Any
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Any.toObject = function toObject(message, options, q) {
                    if (!options)
                        options = {};
                    if (q === undefined)
                        q = 0;
                    if (q > $util.recursionLimit)
                        throw Error("max depth exceeded");
                    var object = {};
                    if (options.defaults) {
                        object.type_url = "";
                        if (options.bytes === String)
                            object.value = "";
                        else {
                            object.value = [];
                            if (options.bytes !== Array)
                                object.value = $util.newBuffer(object.value);
                        }
                    }
                    if (message.type_url != null && Object.hasOwnProperty.call(message, "type_url"))
                        object.type_url = message.type_url;
                    if (message.value != null && Object.hasOwnProperty.call(message, "value"))
                        object.value = options.bytes === String ? $util.base64.encode(message.value, 0, message.value.length) : options.bytes === Array ? Array.prototype.slice.call(message.value) : message.value;
                    return object;
                };
    
                /**
                 * Converts this Any to JSON.
                 * @function toJSON
                 * @memberof google.protobuf.Any
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Any.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                /**
                 * Gets the default type url for Any
                 * @function getTypeUrl
                 * @memberof google.protobuf.Any
                 * @static
                 * @param {string} [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
                 * @returns {string} The default type url
                 */
                Any.getTypeUrl = function getTypeUrl(typeUrlPrefix) {
                    if (typeUrlPrefix === undefined) {
                        typeUrlPrefix = "type.googleapis.com";
                    }
                    return typeUrlPrefix + "/google.protobuf.Any";
                };
    
                return Any;
            })();
    
            return protobuf;
        })();
    
        return google;
    })();

    return $root;
});
