import { SignerInterface } from "./Signer";
import { ProviderInterface } from "./Provider";
import { Serializer } from "./Serializer";
import { TransactionJsonWait, Abi, CallContractOptions, DecodedOperationJson, OperationJson, DeployOptions, TransactionReceipt, EventData, DecodedEventData } from "./interface";
/**
 * The contract class contains the contract ID and contract entries
 * definition needed to encode/decode operations during the
 * interaction with the user and the communication with the RPC node.
 *
 * @example
 *
 * ```ts
 * const { Contract, Provider, Signer, utils } = require("koilib");
 * const rpcNodes = ["http://api.koinos.io"];
 * const privateKey = "f186a5de49797bfd52dc42505c33d75a46822ed5b60046e09d7c336242e20200";
 * const provider = new Provider(rpcNodes);
 * const signer = new Signer({ privateKey, provider });
 * const koinContract = new Contract({
 *   id: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
 *   abi: utils.tokenAbi,
 *   provider,
 *   signer,
 * });
 * const koin = koinContract.functions;
 *
 * async funtion main() {
 *   // Get balance
 *   const { result } = await koin.balanceOf({
 *     owner: "12fN2CQnuJM8cMnWZ1hPtM4knjLME8E4PD",
 *   });
 *   console.log(result)
 *
 *   // Transfer
 *   const { transaction, receipt } = await koin.transfer({
 *     from: signer.getAddress(),
 *     to: "172AB1FgCsYrRAW5cwQ8KjadgxofvgPFd6",
 *     value: "1000010000", // 10.00010000
 *   });
 *   console.log(`Transaction id ${transaction.id} submitted. Receipt:`);
 *   console.log(receipt);
 *
 *   // wait to be mined
 *   const blockNumber = await transaction.wait();
 *   console.log(`Transaction mined. Block number: ${blockNumber}`);
 * }
 *
 * main();
 * ```
 */
export declare class Contract {
    /**
     * Contract ID
     */
    id: Uint8Array;
    /**
     * Set of functions to interact with the smart
     * contract. These functions are automatically generated
     * in the constructor of the class
     *
     * @example
     * ```ts
     * const owner = "1Gvqdo9if6v6tFomEuTuMWP1D7H7U9yksb";
     * await koinContract.functions.balanceOf({ owner });
     * ```
     *
     * @example using options
     * ```ts
     * await koinContract.functions.transfer({
     *   from: "1Gvqdo9if6v6tFomEuTuMWP1D7H7U9yksb",
     *   to: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     *   value: "1",
     * },{
     *   chainId: "EiB-hw5ABo-EXy6fGDd1Iq3gbAenxQ4Qe60pRbEVMVrR9A==",
     *   rcLimit: "100000000",
     *   nonce: "OAI=",
     *   payer: "19JntSm8pSNETT9aHTwAUHC5RMoaSmgZPJ",
     *   payee: "1Gvqdo9if6v6tFomEuTuMWP1D7H7U9yksb",
     *   signTransaction: true,
     *   sendTransaction: true,
     *   broadcast: true,
     *   sendAbis: true,
     * });
     * ```
     */
    functions: {
        [x: string]: <T = Record<string, any>>(args?: any, opts?: CallContractOptions) => Promise<{
            operation: OperationJson;
            transaction?: TransactionJsonWait;
            result?: T;
            receipt?: TransactionReceipt;
        }>;
    };
    /**
     * Application Binary Interface
     */
    abi?: Abi;
    /**
     * Signer interacting with the smart contract
     */
    signer?: SignerInterface;
    /**
     * Provider to connect with the blockchain
     */
    provider?: ProviderInterface;
    /**
     * Serializer to serialize/deserialize data types
     */
    serializer?: Serializer;
    /**
     * Bytecode. Needed to deploy the smart contract.
     */
    bytecode?: Uint8Array;
    /**
     * Options to apply when creating transactions.
     * By default it set rc_limit to 1e8, sendTransaction true,
     * sendAbis true, and nonce undefined (to get it from the blockchain)
     */
    options: CallContractOptions;
    constructor(c: {
        id?: string;
        abi?: Abi;
        bytecode?: Uint8Array;
        options?: CallContractOptions;
        signer?: SignerInterface;
        provider?: ProviderInterface;
        /**
         * Set this option if you can not use _eval_ functions
         * in the current environment. In such cases, the
         * serializer must come from an environment where it
         * is able to use those functions.
         */
        serializer?: Serializer;
    });
    /**
     * Get contract Id
     */
    getId(): string;
    /**
     * Fetch the ABI from the contract meta store and save it in the
     * abi of the contract. The provider must have contract_meta_store
     * microservice enabled.
     * @param opts - options object with 2 boolean: 1) updateFunctions to
     * specify if the contract functions should be regenerated based on
     * the new ABI, and 2) updateSerializer to determine if the serializer
     * should be updated with the types in the new ABI.
     * @returns the new ABI saved in the contract
     */
    fetchAbi(opts?: {
        updateFunctions: boolean;
        updateSerializer: boolean;
    }): Promise<Abi | undefined>;
    /**
     * Create the contract functions based on the ABI
     */
    updateFunctionsFromAbi(): boolean;
    /**
     * Function to deploy a new smart contract.
     * The Bytecode must be defined in the constructor of the class
     * @example
     * ```ts
     * const privateKey = "f186a5de49797bfd52dc42505c33d75a46822ed5b60046e09d7c336242e20200";
     * const provider = new Provider(["http://api.koinos.io"]);
     * const signer = new Signer({ privateKey, provider });
     * const bytecode = new Uint8Array([1, 2, 3, 4]);
     * const contract = new Contract({ signer, provider, bytecode });
     * const { transaction, receipt } = await contract.deploy();
     * console.log(receipt);
     * // wait to be mined
     * const blockNumber = await transaction.wait();
     * console.log(`Contract uploaded in block number ${blockNumber}`);
     * ```
     *
     * @example using options
     * ```ts
     * const { transaction, receipt } = await contract.deploy({
     *   // contract options
     *   abi: JSON.stringify(contract.abi),
     *   authorizesCallContract: true,
     *   authorizesTransactionApplication: true,
     *   authorizesUploadContract: true,
     *
     *   // transaction options
     *   chainId: "EiB-hw5ABo-EXy6fGDd1Iq3gbAenxQ4Qe60pRbEVMVrR9A==",
     *   rcLimit: "100000000",
     *   nonce: "OAI=",
     *   payer: "19JntSm8pSNETT9aHTwAUHC5RMoaSmgZPJ",
     *   payee: "1Gvqdo9if6v6tFomEuTuMWP1D7H7U9yksb",
     *
     *   // sign and broadcast
     *   signTransaction: true,
     *   sendTransaction: true,
     *   broadcast: true,
     * });
     * console.log(receipt);
     * // wait to be mined
     * const blockNumber = await transaction.wait();
     * console.log(`Contract uploaded in block number ${blockNumber}`);
     * ```
     */
    deploy(options?: DeployOptions): Promise<{
        operation: OperationJson;
        transaction?: TransactionJsonWait;
        receipt?: TransactionReceipt;
    }>;
    /**
     * Encondes a contract operation using Koinos serialization
     * and taking the contract entries as reference to build it
     * @param op - Operation to encode
     * @returns Operation encoded
     * @example
     * ```ts
     * const opEncoded = await contract.encodeOperation({
     *   name: "transfer",
     *   args: {
     *     from: "12fN2CQnuJM8cMnWZ1hPtM4knjLME8E4PD",
     *     to: "172AB1FgCsYrRAW5cwQ8KjadgxofvgPFd6",
     *     value: "1000",
     *   }
     * });
     *
     * console.log(opEncoded);
     * // {
     * //   call_contract: {
     * //     contract_id: "19JntSm8pSNETT9aHTwAUHC5RMoaSmgZPJ",
     * //     entry_point: 670398154,
     * //     args: "ChkAEjl6vrl55V2Oym_rzsnMxIqBoie9PHmMEhkAQgjT1UACatdFY3e5QRkyG7OAzwcCCIylGOgH",
     * //   }
     * // }
     * ```
     */
    encodeOperation(op: DecodedOperationJson): Promise<OperationJson>;
    /**
     * Decodes a contract operation to be human readable
     * @example
     * ```ts
     * const opDecoded = await contract.decodeOperation({
     *   call_contract: {
     *     contract_id: "19JntSm8pSNETT9aHTwAUHC5RMoaSmgZPJ",
     *     entry_point: 0x27f576ca,
     *     args: "ChkAEjl6vrl55V2Oym_rzsnMxIqBoie9PHmMEhkAQgjT1UACatdFY3e5QRkyG7OAzwcCCIylGOgH",
     *   }
     * });
     * console.log(opDecoded);
     * // {
     * //   name: "transfer",
     * //   args: {
     * //     from: "12fN2CQnuJM8cMnWZ1hPtM4knjLME8E4PD",
     * //     to: "172AB1FgCsYrRAW5cwQ8KjadgxofvgPFd6",
     * //     value: "1000",
     * //   },
     * // }
     * ```
     */
    decodeOperation(op: OperationJson): Promise<DecodedOperationJson>;
    /**
     * Decode an event received in a receipt
     *
     * @example
     * ```ts
     * const contract = new Contract({
     *   id: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     *   abi: utils.tokenAbi,
     * });
     * const event = {
     *   sequence: 1,
     *   source: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     *   name: "koinos.contracts.token.mint_event",
     *   data: "ChkAxjdqxuwS-B50lPQ-lqhRBA3bf2b2ooAHENrw3Ek=",
     *   impacted: ["1K55BRw87nd64a7aiRarp6DLGRzYvoJo8J"],
     * };
     * const eventDecoded = await contract.decodeEvent(event);
     * console.log(eventDecoded);
     * // {
     * //   sequence: 1,
     * //   source: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     * //   name: "koinos.contracts.token.mint_event",
     * //   data: "ChkAxjdqxuwS-B50lPQ-lqhRBA3bf2b2ooAHENrw3Ek=",
     * //   impacted: ["1K55BRw87nd64a7aiRarp6DLGRzYvoJo8J"],
     * //   args: {
     * //     to: "1K55BRw87nd64a7aiRarp6DLGRzYvoJo8J",
     * //     value: "154613850",
     * //   },
     * // }
     * ```
     */
    decodeEvent(event: EventData): Promise<DecodedEventData>;
}
export default Contract;
