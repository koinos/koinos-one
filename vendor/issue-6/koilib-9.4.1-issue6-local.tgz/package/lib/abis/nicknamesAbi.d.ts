import { Abi } from "../interface";
/**
 * ABI for Nicknames
 *
 * @example
 * ```ts
 * import { Contract, Provider, utils } from "koilib";
 *
 * const provider = new Provider("https://api.koinos.io");
 * const nicknamesContract = new Contract({
 *   id: "1KD9Es7LBBjA1FY3ViCgQJ7e6WH1ipKbhz",
 *   provider,
 *   abi: utils.nicknamesAbi,
 * });
 * const nicknames = nicknamesContract.functions;
 *
 * ...
 *
 * // get the address linked to the nickname "pob"
 * const pobId = `0x${utils.toHexString(new TextEncoder().encode("pob"))}`;
 * const { result } = await nicknames.owner_of({ token_id: pobId });
 * console.log(result);
 *
 * // { value: '159myq5YUhhoVWu3wsHKHiJYKPKGUrGiyv' }
 })();
 * ```
 */
export declare const nicknamesAbi: Abi;
export default nicknamesAbi;
