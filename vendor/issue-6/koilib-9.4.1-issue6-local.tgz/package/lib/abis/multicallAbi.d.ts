import { Abi } from "../interface";
export declare const multicallAbi: Abi;
