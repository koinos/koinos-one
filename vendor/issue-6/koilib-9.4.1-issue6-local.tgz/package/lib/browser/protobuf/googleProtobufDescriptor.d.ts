export declare const googleProtobufDescriptor: {
    google: {
        nested: {
            protobuf: {
                options: {
                    go_package: string;
                    java_package: string;
                    java_outer_classname: string;
                    csharp_namespace: string;
                    objc_class_prefix: string;
                    cc_enable_arenas: boolean;
                    optimize_for: string;
                };
                nested: {
                    FileDescriptorSet: {
                        fields: {
                            file: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                    };
                    FileDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            package: {
                                type: string;
                                id: number;
                            };
                            dependency: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            public_dependency: {
                                rule: string;
                                type: string;
                                id: number;
                                options: {
                                    packed: boolean;
                                };
                            };
                            weak_dependency: {
                                rule: string;
                                type: string;
                                id: number;
                                options: {
                                    packed: boolean;
                                };
                            };
                            message_type: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            enum_type: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            service: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            extension: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                            source_code_info: {
                                type: string;
                                id: number;
                            };
                            syntax: {
                                type: string;
                                id: number;
                            };
                        };
                    };
                    DescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            field: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            extension: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            nested_type: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            enum_type: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            extension_range: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            oneof_decl: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                            reserved_range: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            reserved_name: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        nested: {
                            ExtensionRange: {
                                fields: {
                                    start: {
                                        type: string;
                                        id: number;
                                    };
                                    end: {
                                        type: string;
                                        id: number;
                                    };
                                    options: {
                                        type: string;
                                        id: number;
                                    };
                                };
                            };
                            ReservedRange: {
                                fields: {
                                    start: {
                                        type: string;
                                        id: number;
                                    };
                                    end: {
                                        type: string;
                                        id: number;
                                    };
                                };
                            };
                        };
                    };
                    ExtensionRangeOptions: {
                        fields: {
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                    };
                    FieldDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            number: {
                                type: string;
                                id: number;
                            };
                            label: {
                                type: string;
                                id: number;
                            };
                            type: {
                                type: string;
                                id: number;
                            };
                            type_name: {
                                type: string;
                                id: number;
                            };
                            extendee: {
                                type: string;
                                id: number;
                            };
                            default_value: {
                                type: string;
                                id: number;
                            };
                            oneof_index: {
                                type: string;
                                id: number;
                            };
                            json_name: {
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                            proto3_optional: {
                                type: string;
                                id: number;
                            };
                        };
                        nested: {
                            Type: {
                                values: {
                                    TYPE_DOUBLE: number;
                                    TYPE_FLOAT: number;
                                    TYPE_INT64: number;
                                    TYPE_UINT64: number;
                                    TYPE_INT32: number;
                                    TYPE_FIXED64: number;
                                    TYPE_FIXED32: number;
                                    TYPE_BOOL: number;
                                    TYPE_STRING: number;
                                    TYPE_GROUP: number;
                                    TYPE_MESSAGE: number;
                                    TYPE_BYTES: number;
                                    TYPE_UINT32: number;
                                    TYPE_ENUM: number;
                                    TYPE_SFIXED32: number;
                                    TYPE_SFIXED64: number;
                                    TYPE_SINT32: number;
                                    TYPE_SINT64: number;
                                };
                            };
                            Label: {
                                values: {
                                    LABEL_OPTIONAL: number;
                                    LABEL_REQUIRED: number;
                                    LABEL_REPEATED: number;
                                };
                            };
                        };
                    };
                    OneofDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                        };
                    };
                    EnumDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            value: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                            reserved_range: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            reserved_name: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        nested: {
                            EnumReservedRange: {
                                fields: {
                                    start: {
                                        type: string;
                                        id: number;
                                    };
                                    end: {
                                        type: string;
                                        id: number;
                                    };
                                };
                            };
                        };
                    };
                    EnumValueDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            number: {
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                        };
                    };
                    ServiceDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            method: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                        };
                    };
                    MethodDescriptorProto: {
                        fields: {
                            name: {
                                type: string;
                                id: number;
                            };
                            input_type: {
                                type: string;
                                id: number;
                            };
                            output_type: {
                                type: string;
                                id: number;
                            };
                            options: {
                                type: string;
                                id: number;
                            };
                            client_streaming: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            server_streaming: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                        };
                    };
                    FileOptions: {
                        fields: {
                            java_package: {
                                type: string;
                                id: number;
                            };
                            java_outer_classname: {
                                type: string;
                                id: number;
                            };
                            java_multiple_files: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            java_generate_equals_and_hash: {
                                type: string;
                                id: number;
                                options: {
                                    deprecated: boolean;
                                };
                            };
                            java_string_check_utf8: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            optimize_for: {
                                type: string;
                                id: number;
                                options: {
                                    default: string;
                                };
                            };
                            go_package: {
                                type: string;
                                id: number;
                            };
                            cc_generic_services: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            java_generic_services: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            py_generic_services: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            php_generic_services: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            cc_enable_arenas: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            objc_class_prefix: {
                                type: string;
                                id: number;
                            };
                            csharp_namespace: {
                                type: string;
                                id: number;
                            };
                            swift_prefix: {
                                type: string;
                                id: number;
                            };
                            php_class_prefix: {
                                type: string;
                                id: number;
                            };
                            php_namespace: {
                                type: string;
                                id: number;
                            };
                            php_metadata_namespace: {
                                type: string;
                                id: number;
                            };
                            ruby_package: {
                                type: string;
                                id: number;
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                        reserved: number[][];
                        nested: {
                            OptimizeMode: {
                                values: {
                                    SPEED: number;
                                    CODE_SIZE: number;
                                    LITE_RUNTIME: number;
                                };
                            };
                        };
                    };
                    MessageOptions: {
                        fields: {
                            message_set_wire_format: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            no_standard_descriptor_accessor: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            map_entry: {
                                type: string;
                                id: number;
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                        reserved: number[][];
                    };
                    FieldOptions: {
                        fields: {
                            ctype: {
                                type: string;
                                id: number;
                                options: {
                                    default: string;
                                };
                            };
                            packed: {
                                type: string;
                                id: number;
                            };
                            jstype: {
                                type: string;
                                id: number;
                                options: {
                                    default: string;
                                };
                            };
                            lazy: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            weak: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                        reserved: number[][];
                        nested: {
                            CType: {
                                values: {
                                    STRING: number;
                                    CORD: number;
                                    STRING_PIECE: number;
                                };
                            };
                            JSType: {
                                values: {
                                    JS_NORMAL: number;
                                    JS_STRING: number;
                                    JS_NUMBER: number;
                                };
                            };
                        };
                    };
                    OneofOptions: {
                        fields: {
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                    };
                    EnumOptions: {
                        fields: {
                            allow_alias: {
                                type: string;
                                id: number;
                            };
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                        reserved: number[][];
                    };
                    EnumValueOptions: {
                        fields: {
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                    };
                    ServiceOptions: {
                        fields: {
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                    };
                    MethodOptions: {
                        fields: {
                            deprecated: {
                                type: string;
                                id: number;
                                options: {
                                    default: boolean;
                                };
                            };
                            idempotency_level: {
                                type: string;
                                id: number;
                                options: {
                                    default: string;
                                };
                            };
                            uninterpreted_option: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        extensions: number[][];
                        nested: {
                            IdempotencyLevel: {
                                values: {
                                    IDEMPOTENCY_UNKNOWN: number;
                                    NO_SIDE_EFFECTS: number;
                                    IDEMPOTENT: number;
                                };
                            };
                        };
                    };
                    UninterpretedOption: {
                        fields: {
                            name: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                            identifier_value: {
                                type: string;
                                id: number;
                            };
                            positive_int_value: {
                                type: string;
                                id: number;
                            };
                            negative_int_value: {
                                type: string;
                                id: number;
                            };
                            double_value: {
                                type: string;
                                id: number;
                            };
                            string_value: {
                                type: string;
                                id: number;
                            };
                            aggregate_value: {
                                type: string;
                                id: number;
                            };
                        };
                        nested: {
                            NamePart: {
                                fields: {
                                    name_part: {
                                        rule: string;
                                        type: string;
                                        id: number;
                                    };
                                    is_extension: {
                                        rule: string;
                                        type: string;
                                        id: number;
                                    };
                                };
                            };
                        };
                    };
                    SourceCodeInfo: {
                        fields: {
                            location: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        nested: {
                            Location: {
                                fields: {
                                    path: {
                                        rule: string;
                                        type: string;
                                        id: number;
                                    };
                                    span: {
                                        rule: string;
                                        type: string;
                                        id: number;
                                    };
                                    leading_comments: {
                                        type: string;
                                        id: number;
                                    };
                                    trailing_comments: {
                                        type: string;
                                        id: number;
                                    };
                                    leading_detached_comments: {
                                        rule: string;
                                        type: string;
                                        id: number;
                                    };
                                };
                            };
                        };
                    };
                    GeneratedCodeInfo: {
                        fields: {
                            annotation: {
                                rule: string;
                                type: string;
                                id: number;
                            };
                        };
                        nested: {
                            Annotation: {
                                fields: {
                                    path: {
                                        rule: string;
                                        type: string;
                                        id: number;
                                    };
                                    source_file: {
                                        type: string;
                                        id: number;
                                    };
                                    begin: {
                                        type: string;
                                        id: number;
                                    };
                                    end: {
                                        type: string;
                                        id: number;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
