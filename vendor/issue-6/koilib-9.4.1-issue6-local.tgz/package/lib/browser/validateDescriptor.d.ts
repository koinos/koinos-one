export declare function validateDescriptor(value: unknown): void;
