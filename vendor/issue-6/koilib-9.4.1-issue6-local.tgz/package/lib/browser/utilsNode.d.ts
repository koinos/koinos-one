import { DictionaryGenesisData, GenesisDataDecoded, GenesisDataEncoded } from "./interface";
/**
 * Function to encode genesis data in order to launch a
 * new blockchain. The different values are serialized using
 * protobuffers. One of the arguments is the dictionary which
 * contains the relevant information to perform the serialization.
 * By default the function contains the dictionary for the
 * following keys:
 *
 * - "object_key::head_block"
 * - "object_key::chain_id"
 * - "object_key::genesis_key"
 * - "object_key::resource_limit_data"
 * - "object_key::max_account_resources"
 * - "object_key::protocol_descriptor"
 * - "object_key::compute_bandwidth_registry"
 * - "object_key::block_hash_code"
 *
 * @param genesisDataDecoded - Genesis data where the values are
 * objects.
 * @param dictionary - Set of keys which contains the relevant
 * information to perform the serialization
 *
 * @example
 *
 * ```ts
 * const signer = Signer.fromSeed("seed");
 * const genesisDataDecoded = {
 *   entries: [
 *     {
 *       space: { system: true },
 *       alias: "object_key::genesis_key",
 *       value: signer.address,
 *     },
 *   ],
 * };
 *
 * const genesisData = await encodeGenesisData(genesisDataDecoded);
 * console.log(genesisData);
 *
 * // {
 * //   entries: [
 * //     {
 * //       space: { system: true },
 * //       key: "EiC3nO+XbeKg4C8ugW7M7XdfmJKY4i3l91KoJWxosQPImA==",
 * //       value: "AMpASH7CjUHBpl2QR8E5lGKVjVLAvJRg5g==",
 * //     },
 * //   ],
 * // }
 * ```
 *
 * @example adding a custom dictionary
 *
 * ```ts
 * const contractId = Signer.fromSeed("seed").address;
 * const zone = encodeBase64(decodeBase58(contractId));
 * const genesisDataDecoded = {
 *   entries: [
 *     {
 *       space: { system: true, zone, id: 1 },
 *       key: "difficulty_metadata_key",
 *       value: {
 *         target: encodeBase64url(toUint8Array("F".repeat(64))),
 *         last_block_time: "1641038400000",
 *         difficulty: encodeBase64url(toUint8Array("1".repeat(64))),
 *         target_block_interval: "10",
 *       },
 *     },
 *   ],
 * };
 *
 * const powJson = {
 *   nested: {
 *     mypackage: {
 *       nested: {
 *         difficulty_metadata: {
 *           "fields": {
 *             "target": { "type": "bytes", "id": 1 },
 *             "last_block_time": { "type": "uint64", "id": 2,
 *               "options": { "jstype": "JS_STRING" }
 *             },
 *             "difficulty": { "type": "bytes", "id": 3 },
 *             "target_block_interval": { "type": "uint64", "id": 4,
 *                "options": { "jstype": "JS_STRING" }
 *             }
 *           }
 *         },
 *       }
 *     }
 *   }
 * }
 *
 * const dic = {
 *   difficulty_metadata_key: {
 *     serializer: new Serializer(powJson),
 *     typeName: "difficulty_metadata",
 *   },
 * };
 *
 * const genesisData = await encodeGenesisData(genesisDataDecoded, dic);
 * console.log(genesisData);
 *
 * // {
 * //   entries: [
 * //     {
 * //       key: "difficulty_metadata_key",
 * //       space: {
 * //         id: 1,
 * //         system: true,
 * //         zone: "AMpASH7CjUHBpl2QR8E5lGKVjVLAvJRg5g==",
 * //       },
 * //       value:
 * //         "CiD//////////////////////////////////////////xCAlIus4S8aIBERERERERERERERERERERERERERERERERERERERERERIAo=",
 * //     },
 * //   ],
 * // };
 * ```
 */
export declare function encodeGenesisData(genesisDataDecoded: GenesisDataDecoded, dictionary?: DictionaryGenesisData): Promise<GenesisDataEncoded>;
/**
 * Function to decode genesis data used to launch a
 * new blockchain. The different values are deserialized using
 * protobuffers. One of the arguments is the dictionary which
 * contains the relevant information for the deserialization.
 * By default the function contains the dictionary for the
 * following keys:
 *
 * - "object_key::head_block"
 * - "object_key::chain_id"
 * - "object_key::genesis_key"
 * - "object_key::resource_limit_data"
 * - "object_key::max_account_resources"
 * - "object_key::protocol_descriptor"
 * - "object_key::compute_bandwidth_registry"
 * - "object_key::block_hash_code"
 *
 * @param genesisData - Genesis data
 * @param dictionary - Set of keys which contains the relevant
 * information to perform the deserialization
 *
 * @example
 *
 * ```ts
 * const genesisData = {
 *   entries: [
 *     {
 *       space: { system: true },
 *       key: "EiC3nO+XbeKg4C8ugW7M7XdfmJKY4i3l91KoJWxosQPImA==",
 *       value: "AMpASH7CjUHBpl2QR8E5lGKVjVLAvJRg5g==",
 *     },
 *   ],
 * }
 *
 * const genesisDataDecoded = await decodeGenesisData(genesisData);
 * console.log(genesisDataDecoded);
 *
 * // {
 * //   entries: [
 * //     {
 * //       space: { system: true },
 * //       key: "EiC3nO+XbeKg4C8ugW7M7XdfmJKY4i3l91KoJWxosQPImA==",
 * //       alias: "object_key::genesis_key",
 * //       value: "1KSQWDyUnFZ48Pf2hsW8Akh1b5fKUWc8Z3",
 * //     },
 * //   ],
 * // };
 * ```
 *
 * @example adding a custom dictionary
 *
 * ```ts
 * const genesisData = {
 *   entries: [
 *     {
 *       key: "difficulty_metadata_key",
 *       space: {
 *         id: 1,
 *         system: true,
 *         zone: "AMpASH7CjUHBpl2QR8E5lGKVjVLAvJRg5g==",
 *       },
 *       value:
 *         "CiD//////////////////////////////////////////xCAlIus4S8aIBERERERERERERERERERERERERERERERERERERERERERIAo=",
 *     },
 *   ],
 * };
 *
 * const powJson = {
 *   nested: {
 *     mypackage: {
 *       nested: {
 *         difficulty_metadata: {
 *           "fields": {
 *             "target": { "type": "bytes", "id": 1 },
 *             "last_block_time": { "type": "uint64", "id": 2,
 *               "options": { "jstype": "JS_STRING" }
 *             },
 *             "difficulty": { "type": "bytes", "id": 3 },
 *             "target_block_interval": { "type": "uint64", "id": 4,
 *                "options": { "jstype": "JS_STRING" }
 *             }
 *           }
 *         },
 *       }
 *     }
 *   }
 * }
 *
 * const dic = {
 *   difficulty_metadata_key: {
 *     serializer: new Serializer(powJson),
 *     typeName: "difficulty_metadata",
 *   },
 * };
 *
 * const genesisDataDecoded = await decodeGenesisData(genesisData, dic);
 * console.log(genesisData);
 *
 * // {
 * //   entries: [
 * //     {
 * //       space: { system: true, zone, id: 1 },
 * //       key: "difficulty_metadata_key",
 * //       value: {
 * //         target: "__________________________________________8=",
 * //         last_block_time: "1641038400000",
 * //         difficulty: "ERERERERERERERERERERERERERERERERERERERERERE=",
 * //         target_block_interval: "10",
 * //       },
 * //     },
 * //   ],
 * // };
 * ```
 */
export declare function decodeGenesisData(genesisData: GenesisDataEncoded, dictionary?: DictionaryGenesisData): Promise<GenesisDataDecoded>;
export declare const ChainTypes: {
    nested: {
        koinos: {
            options: {
                go_package: string;
            };
            nested: {
                block_topology: {
                    fields: {
                        id: {
                            type: string;
                            id: number;
                            options: {
                                "(btype)": string;
                            };
                        };
                        height: {
                            type: string;
                            id: number;
                            options: {
                                jstype: string;
                            };
                        };
                        previous: {
                            type: string;
                            id: number;
                            options: {
                                "(btype)": string;
                            };
                        };
                    };
                };
                bytes_type: {
                    values: {
                        BASE64: number;
                        BASE58: number;
                        HEX: number;
                        BLOCK_ID: number;
                        TRANSACTION_ID: number;
                        CONTRACT_ID: number;
                        ADDRESS: number;
                    };
                };
                _btype: {
                    oneof: string[];
                };
                btype: {
                    type: string;
                    id: number;
                    extend: string;
                    options: {
                        proto3_optional: boolean;
                    };
                };
                protocol: {
                    options: {
                        go_package: string;
                    };
                    nested: {
                        object_space: {
                            fields: {
                                system: {
                                    type: string;
                                    id: number;
                                };
                                zone: {
                                    type: string;
                                    id: number;
                                };
                                id: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        event_data: {
                            fields: {
                                sequence: {
                                    type: string;
                                    id: number;
                                };
                                source: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                name: {
                                    type: string;
                                    id: number;
                                };
                                data: {
                                    type: string;
                                    id: number;
                                };
                                impacted: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                            };
                        };
                        contract_call_bundle: {
                            fields: {
                                contract_id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                entry_point: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        system_call_target: {
                            oneofs: {
                                target: {
                                    oneof: string[];
                                };
                            };
                            fields: {
                                thunk_id: {
                                    type: string;
                                    id: number;
                                };
                                system_call_bundle: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        upload_contract_operation: {
                            fields: {
                                contract_id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                bytecode: {
                                    type: string;
                                    id: number;
                                };
                                abi: {
                                    type: string;
                                    id: number;
                                };
                                authorizes_call_contract: {
                                    type: string;
                                    id: number;
                                };
                                authorizes_transaction_application: {
                                    type: string;
                                    id: number;
                                };
                                authorizes_upload_contract: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        call_contract_operation: {
                            fields: {
                                contract_id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                entry_point: {
                                    type: string;
                                    id: number;
                                };
                                args: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        set_system_call_operation: {
                            fields: {
                                call_id: {
                                    type: string;
                                    id: number;
                                };
                                target: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        set_system_contract_operation: {
                            fields: {
                                contract_id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                system_contract: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        operation: {
                            oneofs: {
                                op: {
                                    oneof: string[];
                                };
                            };
                            fields: {
                                upload_contract: {
                                    type: string;
                                    id: number;
                                };
                                call_contract: {
                                    type: string;
                                    id: number;
                                };
                                set_system_call: {
                                    type: string;
                                    id: number;
                                };
                                set_system_contract: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        transaction_header: {
                            fields: {
                                chain_id: {
                                    type: string;
                                    id: number;
                                };
                                rc_limit: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                nonce: {
                                    type: string;
                                    id: number;
                                };
                                operation_merkle_root: {
                                    type: string;
                                    id: number;
                                };
                                payer: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                payee: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                            };
                        };
                        transaction: {
                            fields: {
                                id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                header: {
                                    type: string;
                                    id: number;
                                };
                                operations: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                signatures: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        transaction_receipt: {
                            fields: {
                                id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                payer: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                max_payer_rc: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                rc_limit: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                rc_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                disk_storage_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                network_bandwidth_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                compute_bandwidth_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                reverted: {
                                    type: string;
                                    id: number;
                                };
                                events: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                logs: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                state_delta_entries: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        block_header: {
                            fields: {
                                previous: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                height: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                timestamp: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                previous_state_merkle_root: {
                                    type: string;
                                    id: number;
                                };
                                transaction_merkle_root: {
                                    type: string;
                                    id: number;
                                };
                                signer: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                approved_proposals: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                            };
                        };
                        block: {
                            fields: {
                                id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                header: {
                                    type: string;
                                    id: number;
                                };
                                transactions: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                signature: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        block_receipt: {
                            fields: {
                                id: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                height: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                disk_storage_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                network_bandwidth_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                compute_bandwidth_used: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                state_merkle_root: {
                                    type: string;
                                    id: number;
                                };
                                events: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                transaction_receipts: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                logs: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                disk_storage_charged: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                network_bandwidth_charged: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                compute_bandwidth_charged: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                state_delta_entries: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        state_delta_entry: {
                            oneofs: {
                                _value: {
                                    oneof: string[];
                                };
                            };
                            fields: {
                                object_space: {
                                    type: string;
                                    id: number;
                                };
                                key: {
                                    type: string;
                                    id: number;
                                };
                                value: {
                                    type: string;
                                    id: number;
                                    options: {
                                        proto3_optional: boolean;
                                    };
                                };
                            };
                        };
                    };
                };
                chain: {
                    options: {
                        go_package: string;
                    };
                    nested: {
                        error_data: {
                            fields: {
                                message: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        result: {
                            oneofs: {
                                value: {
                                    oneof: string[];
                                };
                            };
                            fields: {
                                object: {
                                    type: string;
                                    id: number;
                                };
                                error: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        object_space: {
                            fields: {
                                system: {
                                    type: string;
                                    id: number;
                                };
                                zone: {
                                    type: string;
                                    id: number;
                                };
                                id: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        database_key: {
                            fields: {
                                space: {
                                    type: string;
                                    id: number;
                                };
                                key: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        max_account_resources: {
                            fields: {
                                value: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                            };
                        };
                        privilege: {
                            values: {
                                kernel_mode: number;
                                user_mode: number;
                            };
                        };
                        head_info: {
                            fields: {
                                head_topology: {
                                    type: string;
                                    id: number;
                                };
                                head_block_time: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                last_irreversible_block: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                            };
                        };
                        caller_data: {
                            fields: {
                                caller: {
                                    type: string;
                                    id: number;
                                    options: {
                                        "(btype)": string;
                                    };
                                };
                                caller_privilege: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        argument_data: {
                            fields: {
                                entry_point: {
                                    type: string;
                                    id: number;
                                };
                                arguments: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        resource_limit_data: {
                            fields: {
                                disk_storage_limit: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                disk_storage_cost: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                network_bandwidth_limit: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                network_bandwidth_cost: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                compute_bandwidth_limit: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                                compute_bandwidth_cost: {
                                    type: string;
                                    id: number;
                                    options: {
                                        jstype: string;
                                    };
                                };
                            };
                        };
                        contract_metadata_object: {
                            fields: {
                                hash: {
                                    type: string;
                                    id: number;
                                };
                                system: {
                                    type: string;
                                    id: number;
                                };
                                authorizes_call_contract: {
                                    type: string;
                                    id: number;
                                };
                                authorizes_transaction_application: {
                                    type: string;
                                    id: number;
                                };
                                authorizes_upload_contract: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        compute_bandwidth_entry: {
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                compute: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        compute_bandwidth_registry: {
                            fields: {
                                entries: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        genesis_entry: {
                            fields: {
                                space: {
                                    type: string;
                                    id: number;
                                };
                                key: {
                                    type: string;
                                    id: number;
                                };
                                value: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        genesis_data: {
                            fields: {
                                entries: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        dsa: {
                            values: {
                                ecdsa_secp256k1: number;
                            };
                        };
                    };
                };
            };
        };
        google: {
            nested: {
                protobuf: {
                    options: {
                        go_package: string;
                        java_package: string;
                        java_outer_classname: string;
                        csharp_namespace: string;
                        objc_class_prefix: string;
                        cc_enable_arenas: boolean;
                        optimize_for: string;
                    };
                    nested: {
                        FileDescriptorSet: {
                            edition: string;
                            fields: {
                                file: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        FileDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                package: {
                                    type: string;
                                    id: number;
                                };
                                dependency: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                public_dependency: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                weak_dependency: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                message_type: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                enum_type: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                service: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                extension: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                                source_code_info: {
                                    type: string;
                                    id: number;
                                };
                                syntax: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        DescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                field: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                extension: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                nested_type: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                enum_type: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                extension_range: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                oneof_decl: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                                reserved_range: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                reserved_name: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                ExtensionRange: {
                                    fields: {
                                        start: {
                                            type: string;
                                            id: number;
                                        };
                                        end: {
                                            type: string;
                                            id: number;
                                        };
                                        options: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                                ReservedRange: {
                                    fields: {
                                        start: {
                                            type: string;
                                            id: number;
                                        };
                                        end: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                            };
                        };
                        ExtensionRangeOptions: {
                            edition: string;
                            fields: {
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                        };
                        FieldDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                number: {
                                    type: string;
                                    id: number;
                                };
                                label: {
                                    type: string;
                                    id: number;
                                };
                                type: {
                                    type: string;
                                    id: number;
                                };
                                type_name: {
                                    type: string;
                                    id: number;
                                };
                                extendee: {
                                    type: string;
                                    id: number;
                                };
                                default_value: {
                                    type: string;
                                    id: number;
                                };
                                oneof_index: {
                                    type: string;
                                    id: number;
                                };
                                json_name: {
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                                proto3_optional: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Type: {
                                    values: {
                                        TYPE_DOUBLE: number;
                                        TYPE_FLOAT: number;
                                        TYPE_INT64: number;
                                        TYPE_UINT64: number;
                                        TYPE_INT32: number;
                                        TYPE_FIXED64: number;
                                        TYPE_FIXED32: number;
                                        TYPE_BOOL: number;
                                        TYPE_STRING: number;
                                        TYPE_GROUP: number;
                                        TYPE_MESSAGE: number;
                                        TYPE_BYTES: number;
                                        TYPE_UINT32: number;
                                        TYPE_ENUM: number;
                                        TYPE_SFIXED32: number;
                                        TYPE_SFIXED64: number;
                                        TYPE_SINT32: number;
                                        TYPE_SINT64: number;
                                    };
                                };
                                Label: {
                                    values: {
                                        LABEL_OPTIONAL: number;
                                        LABEL_REQUIRED: number;
                                        LABEL_REPEATED: number;
                                    };
                                };
                            };
                        };
                        OneofDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        EnumDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                value: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                                reserved_range: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                reserved_name: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                EnumReservedRange: {
                                    fields: {
                                        start: {
                                            type: string;
                                            id: number;
                                        };
                                        end: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                            };
                        };
                        EnumValueDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                number: {
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        ServiceDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                method: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        MethodDescriptorProto: {
                            edition: string;
                            fields: {
                                name: {
                                    type: string;
                                    id: number;
                                };
                                input_type: {
                                    type: string;
                                    id: number;
                                };
                                output_type: {
                                    type: string;
                                    id: number;
                                };
                                options: {
                                    type: string;
                                    id: number;
                                };
                                client_streaming: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                server_streaming: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                            };
                        };
                        FileOptions: {
                            edition: string;
                            fields: {
                                java_package: {
                                    type: string;
                                    id: number;
                                };
                                java_outer_classname: {
                                    type: string;
                                    id: number;
                                };
                                java_multiple_files: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                java_generate_equals_and_hash: {
                                    type: string;
                                    id: number;
                                    options: {
                                        deprecated: boolean;
                                    };
                                };
                                java_string_check_utf8: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                optimize_for: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: string;
                                    };
                                };
                                go_package: {
                                    type: string;
                                    id: number;
                                };
                                cc_generic_services: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                java_generic_services: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                py_generic_services: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                php_generic_services: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                cc_enable_arenas: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                objc_class_prefix: {
                                    type: string;
                                    id: number;
                                };
                                csharp_namespace: {
                                    type: string;
                                    id: number;
                                };
                                swift_prefix: {
                                    type: string;
                                    id: number;
                                };
                                php_class_prefix: {
                                    type: string;
                                    id: number;
                                };
                                php_namespace: {
                                    type: string;
                                    id: number;
                                };
                                php_metadata_namespace: {
                                    type: string;
                                    id: number;
                                };
                                ruby_package: {
                                    type: string;
                                    id: number;
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                            reserved: number[][];
                            nested: {
                                OptimizeMode: {
                                    values: {
                                        SPEED: number;
                                        CODE_SIZE: number;
                                        LITE_RUNTIME: number;
                                    };
                                };
                            };
                        };
                        MessageOptions: {
                            edition: string;
                            fields: {
                                message_set_wire_format: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                no_standard_descriptor_accessor: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                map_entry: {
                                    type: string;
                                    id: number;
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                            reserved: number[][];
                        };
                        FieldOptions: {
                            edition: string;
                            fields: {
                                ctype: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: string;
                                    };
                                };
                                packed: {
                                    type: string;
                                    id: number;
                                };
                                jstype: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: string;
                                    };
                                };
                                lazy: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                weak: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                            reserved: number[][];
                            nested: {
                                CType: {
                                    values: {
                                        STRING: number;
                                        CORD: number;
                                        STRING_PIECE: number;
                                    };
                                };
                                JSType: {
                                    values: {
                                        JS_NORMAL: number;
                                        JS_STRING: number;
                                        JS_NUMBER: number;
                                    };
                                };
                            };
                        };
                        OneofOptions: {
                            edition: string;
                            fields: {
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                        };
                        EnumOptions: {
                            edition: string;
                            fields: {
                                allow_alias: {
                                    type: string;
                                    id: number;
                                };
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                            reserved: number[][];
                        };
                        EnumValueOptions: {
                            edition: string;
                            fields: {
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                        };
                        ServiceOptions: {
                            edition: string;
                            fields: {
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                        };
                        MethodOptions: {
                            edition: string;
                            fields: {
                                deprecated: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: boolean;
                                    };
                                };
                                idempotency_level: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: string;
                                    };
                                };
                                uninterpreted_option: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            extensions: number[][];
                            nested: {
                                IdempotencyLevel: {
                                    values: {
                                        IDEMPOTENCY_UNKNOWN: number;
                                        NO_SIDE_EFFECTS: number;
                                        IDEMPOTENT: number;
                                    };
                                };
                            };
                        };
                        UninterpretedOption: {
                            edition: string;
                            fields: {
                                name: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                identifier_value: {
                                    type: string;
                                    id: number;
                                };
                                positive_int_value: {
                                    type: string;
                                    id: number;
                                };
                                negative_int_value: {
                                    type: string;
                                    id: number;
                                };
                                double_value: {
                                    type: string;
                                    id: number;
                                };
                                string_value: {
                                    type: string;
                                    id: number;
                                };
                                aggregate_value: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                NamePart: {
                                    fields: {
                                        name_part: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                        };
                                        is_extension: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                            };
                        };
                        SourceCodeInfo: {
                            edition: string;
                            fields: {
                                location: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Location: {
                                    fields: {
                                        path: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                            options: {
                                                packed: boolean;
                                            };
                                        };
                                        span: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                            options: {
                                                packed: boolean;
                                            };
                                        };
                                        leading_comments: {
                                            type: string;
                                            id: number;
                                        };
                                        trailing_comments: {
                                            type: string;
                                            id: number;
                                        };
                                        leading_detached_comments: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                            };
                        };
                        GeneratedCodeInfo: {
                            edition: string;
                            fields: {
                                annotation: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Annotation: {
                                    fields: {
                                        path: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                            options: {
                                                packed: boolean;
                                            };
                                        };
                                        source_file: {
                                            type: string;
                                            id: number;
                                        };
                                        begin: {
                                            type: string;
                                            id: number;
                                        };
                                        end: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
