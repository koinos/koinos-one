import { Abi, TypeField } from "./interface";
/**
 * Converts an hex string to Uint8Array
 */
export declare function toUint8Array(hex: string): Uint8Array;
/**
 * Converts Uint8Array to hex string
 */
export declare function toHexString(buffer: Uint8Array): string;
/**
 * Encodes an Uint8Array in base58
 */
export declare function encodeBase58(buffer: Uint8Array): string;
/**
 * Decodes a buffer formatted in base58
 */
export declare function decodeBase58(bs58: string): Uint8Array;
/**
 * Encodes an Uint8Array in base64url
 */
export declare function encodeBase64url(buffer: Uint8Array): string;
/**
 * Decodes a buffer formatted in base64url
 */
export declare function decodeBase64url(bs64url: string): Uint8Array;
/**
 * Encodes an Uint8Array in base64
 */
export declare function encodeBase64(buffer: Uint8Array): string;
export declare function multihash(buffer: Uint8Array, code?: string): Uint8Array;
/**
 * Decodes a buffer formatted in base64
 */
export declare function decodeBase64(bs64: string): Uint8Array;
/**
 * Calculates the merkle root of sha256 hashes
 */
export declare function calculateMerkleRoot(hashes: Uint8Array[]): Uint8Array;
/**
 * Encodes a public or private key in base58 using
 * the bitcoin format (see [Bitcoin Base58Check encoding](https://en.bitcoin.it/wiki/Base58Check_encoding)
 * and [Bitcoin WIF](https://en.bitcoin.it/wiki/Wallet_import_format)).
 *
 * For private keys this encode is also known as
 * wallet import format (WIF).
 */
export declare function bitcoinEncode(buffer: Uint8Array, type: "public" | "private", compressed?: boolean): string;
/**
 * Decodes a public or private key formatted in base58 using
 * the bitcoin format (see [Bitcoin Base58Check encoding](https://en.bitcoin.it/wiki/Base58Check_encoding)
 * and [Bitcoin WIF](https://en.bitcoin.it/wiki/Wallet_import_format)).
 *
 * For private keys this encode is also known as
 * wallet import format (WIF).
 */
export declare function bitcoinDecode(value: string): Uint8Array;
/**
 * Computes a bitcoin address, which is the format used in Koinos
 *
 * address = bitcoinEncode( ripemd160 ( sha256 ( publicKey ) ) )
 */
export declare function bitcoinAddress(publicKey: Uint8Array): string;
/**
 * Checks if the last 4 bytes matches with the double sha256
 * of the first part
 */
export declare function isChecksum(buffer: Uint8Array): boolean;
/**
 * Checks if the checksum of an address is correct.
 *
 * The address has 3 parts in this order:
 * - prefix: 1 byte
 * - data: 20 bytes
 * - checksum: 4 bytes
 *
 * checks:
 * - It must be "pay to public key hash" (P2PKH). That is prefix 0
 * - checksum = first 4 bytes of sha256(sha256(prefix + data))
 *
 * See [How to generate a bitcoin address step by step](https://medium.com/coinmonks/how-to-generate-a-bitcoin-address-step-by-step-9d7fcbf1ad0b).
 */
export declare function isChecksumAddress(address: string | Uint8Array): boolean;
/**
 * Checks if the checksum of an private key WIF is correct.
 *
 * The private key WIF has 3 parts in this order:
 * - prefix: 1 byte
 * - private key: 32 bytes
 * - compressed: 1 byte for compressed public key (no byte for uncompressed)
 * - checksum: 4 bytes
 *
 * checks:
 * - It must use version 0x80 in the prefix
 * - If the corresponding public key is compressed the byte 33 must be 0x01
 * - checksum = first 4 bytes of
 *     sha256(sha256(prefix + private key + compressed))
 *
 * See [Bitcoin WIF](https://en.bitcoin.it/wiki/Wallet_import_format).
 */
export declare function isChecksumWif(wif: string | Uint8Array): boolean;
/**
 * Function to format a number in a decimal point number
 * @example
 * ```js
 * const amount = formatUnits("123456", 8);
 * console.log(amount);
 * // '0.00123456'
 * ```
 */
export declare function formatUnits(value: string | number | bigint, decimals: number): string;
/**
 * Function to format a decimal point number in an integer
 * @example
 * ```js
 * const amount = parseUnits("0.00123456", 8);
 * console.log(amount);
 * // '123456'
 * ```
 */
export declare function parseUnits(value: string, decimals: number): string;
export declare function btypeDecodeValue(valueEncoded: unknown, typeField: TypeField, verifyChecksum: boolean): unknown;
export declare function btypeEncodeValue(valueDecoded: unknown, typeField: TypeField, verifyChecksum: boolean): unknown;
export declare function btypeDecode(valueEncoded: Record<string, unknown> | unknown[], fields: Record<string, TypeField>, verifyChecksum: boolean): Record<string, unknown>;
export declare function btypeEncode(valueDecoded: Record<string, unknown> | unknown[], fields: Record<string, TypeField>, verifyChecksum: boolean): Record<string, unknown>;
/**
 * ABI for tokens
 *
 * @example
 * ```ts
 * import { Contract, Provider, utils } from "koilib";
 *
 * const provider = new Provider("https://api.koinos.io");
 * const koinContract = new Contract({
 *   id: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
 *   provider,
 *   abi: utils.tokenAbi,
 * });
 * ```
 */
export declare const tokenAbi: Abi;
/**
 * ABI for NFTs
 *
 * @example
 * ```ts
 * import { Contract, Provider, utils } from "koilib";
 *
 * const provider = new Provider("https://api.koinos.io");
 * const nicknamesContract = new Contract({
 *   id: "1KD9Es7LBBjA1FY3ViCgQJ7e6WH1ipKbhz",
 *   provider,
 *   abi: utils.nftAbi,
 * });
 * const nicknames = nicknamesContract.functions;
 *
 * ...
 *
 * // get the address linked to the nickname "pob"
 * const pobId = `0x${utils.toHexString(new TextEncoder().encode("pob"))}`;
 * const { result } = await nicknames.ownerOf({ token_id: pobId });
 * console.log(result);
 *
 * // { value: '159myq5YUhhoVWu3wsHKHiJYKPKGUrGiyv' }
 })();
 * ```
 */
export declare const nftAbi: Abi;
export * from "./abis/nicknamesAbi";
