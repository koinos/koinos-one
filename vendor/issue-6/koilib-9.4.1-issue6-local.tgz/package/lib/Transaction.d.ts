import { Contract } from "./Contract";
import { ProviderInterface } from "./Provider";
import { SignerInterface } from "./Signer";
import { Abi, OperationJson, SendTransactionOptions, TransactionHeaderJson, TransactionJson, TransactionOptions, TransactionReceipt, WaitFunction } from "./interface";
export declare class Transaction {
    /**
     * Signer interacting with the smart contracts
     */
    signer?: SignerInterface;
    /**
     * Provider to connect with the blockchain
     */
    provider?: ProviderInterface;
    /**
     * Transaction
     */
    transaction: TransactionJson;
    /**
     * Function to wait for the transaction to be mined
     */
    waitFunction?: WaitFunction;
    /**
     * Transaction options
     */
    options: TransactionOptions;
    constructor(c?: {
        signer?: SignerInterface;
        provider?: ProviderInterface;
        transaction?: TransactionJson;
        options?: TransactionOptions;
    });
    /**
     * Function to push an operation to the transaction. It can be created
     * in several ways. Example:
     *
     * @example
     * ```ts
     * const koin = new Contract({
     *   id: "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     *   abi: utils.tokenAbi,
     * }).functions;
     * const signer = Signer.fromSeed("my seed");
     * const provider = new Provider(["https://api.koinos.io"]);
     * signer.provider = provider;
     * const tx = new Transaction({ signer });
     *
     * // Method 1 (using 2 arguments)
     * // note that with 2 arguments it is not necessary to
     * // set "onlyOperation: true". For the rest of the
     * // methods it's necessary to do that.
     * await tx.pushOperation(koin.transfer, {
     *   from: "1NRYHBYr9qxYQAeVqfdSvyjJemRQ4qD3Mt",
     *   to: "13UdKjYuzfBYbB6bGLQkUN9DJRFPCmG1mU",
     *   value: "1000",
     * });
     *
     * // Method 2
     * await tx.pushOperation(
     *   koin.transfer({
     *     from: "1NRYHBYr9qxYQAeVqfdSvyjJemRQ4qD3Mt",
     *     to: "13UdKjYuzfBYbB6bGLQkUN9DJRFPCmG1mU",
     *     value: "1000",
     *   },{
     *    onlyOperation: true,
     *   })
     * );
     *
     * // Method 3
     * await tx.pushOperation(
     *   await koin.transfer({
     *     from: "1NRYHBYr9qxYQAeVqfdSvyjJemRQ4qD3Mt",
     *     to: "13UdKjYuzfBYbB6bGLQkUN9DJRFPCmG1mU",
     *     value: "1000",
     *   },{
     *    onlyOperation: true,
     *   })
     * );
     *
     * // Method 4
     * const { operation } = await koin.transfer({
     *   from: "1NRYHBYr9qxYQAeVqfdSvyjJemRQ4qD3Mt",
     *   to: "13UdKjYuzfBYbB6bGLQkUN9DJRFPCmG1mU",
     *   value: "1000",
     * },{
     *  onlyOperation: true,
     * });
     * await tx.pushOperation(operation)
     * ```
     *
     */
    pushOperation(input: OperationJson | {
        operation: OperationJson;
    } | Promise<{
        operation: OperationJson;
    }> | Contract["functions"]["x"], args?: unknown): Promise<void>;
    static computeTransactionId(txHeader: TransactionHeaderJson): string;
    /**
     * Function to prepare a transaction
     * @param tx - Do not set the nonce to get it from the blockchain
     * using the provider. The rc_limit is 1e8 by default.
     * @param provider - Provider
     * @param payer - payer to be used in case it is not defined in the transaction
     * @returns A prepared transaction.
     */
    static prepareTransaction(tx: TransactionJson, provider?: ProviderInterface, payer?: string): Promise<TransactionJson>;
    /**
     * Function to prepare the transaction (set headers, merkle
     * root, etc)
     */
    prepare(options?: TransactionOptions): Promise<TransactionJson>;
    /**
     * Update the rc limit with a new value and update the
     * transaction ID accordingly. The signatures will be removed
     * if the transaction ID changed
     */
    adjustRcLimit(newRcLimit: string | number): void;
    /**
     * Function to sign the transaction
     */
    sign(abis?: Record<string, Abi>): Promise<TransactionJson>;
    /**
     * Function to broadcast the transaction
     */
    send(options?: SendTransactionOptions): Promise<TransactionReceipt>;
    wait(type?: "byBlock" | "byTransactionId", timeout?: number): Promise<{
        blockId: string;
        blockNumber?: number;
    }>;
}
