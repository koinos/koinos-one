import { Root, Type, INamespace } from "protobufjs";
/**
 * The serializer class serialize and deserialize data using
 * protocol buffers. It accepts the descriptor in JSON or binary format
 *
 * NOTE: This class uses the [protobufjs](https://www.npmjs.com/package/protobufjs)
 * library internally, which uses reflection (use of _eval_
 * and _new Function_) for the construction of the types.
 * This could cause issues in environments where _eval_ is not
 * allowed, like in browser extensions. In such cases, this class
 * must be confined in a [sandbox environment](https://developer.chrome.com/docs/apps/app_external/#sandboxing)
 * where _eval_ is allowed. This is the principal reason of
 * having the serializer in a separate class.
 *
 * @example
 *
 * ```ts
 * // using descriptor JSON
 * const descriptorJson = {
 *   nested: {
 *     awesomepackage: {
 *       nested: {
 *         AwesomeMessage: {
 *           fields: {
 *             awesome_field: {
 *               type: "string",
 *               id: 1,
 *             },
 *           },
 *         },
 *       },
 *     },
 *   },
 * };
 * const serializer1 = new Serializer(descriptorJson);
 * const message1 = await serializer1.deserialize(
 *   "CgZrb2lub3M=",
 *   "AwesomeMessage"
 * );
 * console.log(message1);
 * // { awesome_field: 'koinos' }
 *
 * // using descriptor binary
 * const descriptorBinary =
 *   "Cl4KDWF3ZXNvbWUucHJvdG8SDmF3ZXNvbWVwYWN" +
 *   "rYWdlIjUKDkF3ZXNvbWVNZXNzYWdlEiMKDWF3ZX" +
 *   "NvbWVfZmllbGQYASABKAlSDGF3ZXNvbWVGaWVsZ" +
 *   "GIGcHJvdG8z";
 * const serializer2 = new Serializer(descriptorBinary);
 * const message2 = await serializer2.deserialize(
 *   "CgZrb2lub3M=",
 *   "AwesomeMessage"
 * );
 * console.log(message2);
 * // { awesome_field: 'koinos' }
 * ```
 */
export declare class Serializer {
    /**
     * Protobuffers descriptor in JSON format.
     * See https://www.npmjs.com/package/protobufjs#using-json-descriptors
     */
    types: INamespace | string;
    /**
     * Protobuffer definitions
     */
    root: Root;
    /**
     * Default type for all serializations
     */
    defaultType?: Type;
    /**
     * Type name for arguments when using
     * [[Provider.invokeSystemCall]]
     */
    argumentsTypeName?: string;
    /**
     * Type name for the output when using
     * [[Provider.invokeSystemCall]]
     */
    returnTypeName?: string;
    /**
     * Preformat bytes for base64url, base58 or hex string
     */
    bytesConversion: boolean;
    /**
     * Verify checksum in addresses during serialization
     * or deserialization
     */
    verifyChecksum: {
        serialize: boolean;
        deserialize: boolean;
    };
    constructor(types: INamespace | string, opts?: {
        /**
         * Default type name. Use this option when you
         * always want to serialize/deserialize the same type
         */
        defaultTypeName?: string;
        /**
         * Type name for arguments when using
         * [[Provider.invokeSystemCall]]
         */
        argumentsTypeName?: string;
        /**
         * Type name for the output when using
         * [[Provider.invokeSystemCall]]
         */
        returnTypeName?: string;
        /**
         * Bytes conversion. Option to preformat bytes
         * when "(koinos_bytes_type)" is defined in the type
         * definitions. By default it is true.
         */
        bytesConversion?: boolean;
    });
    btypeDecode(valueBtypeEncoded: Record<string, unknown> | unknown[], protobufType: Type, verifyChecksum: boolean): Record<string, unknown>;
    btypeEncode(valueBtypeDecoded: Record<string, unknown> | unknown[], protobufType: Type, verifyChecksum: boolean): Record<string, unknown>;
    /**
     * Function to encode a type using the protobuffer definitions
     * It also prepares the bytes for special cases (base58, hex string)
     * when bytesConversion param is true.
     */
    serialize(valueDecoded: Record<string, unknown>, typeName?: string, opts?: {
        bytesConversion?: boolean;
        verifyChecksum?: boolean;
    }): Promise<Uint8Array>;
    /**
     * Function to decode bytes using the protobuffer definitions
     * It also encodes the bytes for special cases (base58, hex string)
     * when bytesConversion param is true.
     */
    deserialize<T = Record<string, unknown>>(valueEncoded: string | Uint8Array, typeName?: string, opts?: {
        bytesConversion?: boolean;
        verifyChecksum?: boolean;
    }): Promise<T>;
}
export default Serializer;
