import { BlockJson, TransactionJson, CallContractOperationJson, TransactionReceipt, TransactionJsonWait, BlockTopology, GetBlockOptions, BlockReceipt } from "./interface";
import { Serializer } from "./Serializer";
export interface ProviderInterface {
    call: <T = unknown>(method: string, params: unknown) => Promise<T>;
    getNonce: (account: string, deserialize?: boolean) => Promise<number | string>;
    getNextNonce: (account: string) => Promise<string>;
    getAccountRc: (account: string) => Promise<string>;
    getTransactionsById: (transactionIds: string[]) => Promise<{
        transactions: {
            transaction: TransactionJson;
            containing_blocks: string[];
        }[];
    }>;
    getBlocksById: (blockIds: string[], opts?: GetBlockOptions) => Promise<{
        block_items: {
            block_id: string;
            block_height: string;
            block: BlockJson;
            receipt: BlockReceipt;
        }[];
    }>;
    getHeadInfo: () => Promise<{
        head_block_time: string;
        head_topology: BlockTopology;
        head_state_merkle_root: string;
        last_irreversible_block: string;
    }>;
    getChainId: () => Promise<string>;
    getBlocks: (height: number, numBlocks?: number, idRef?: string, opts?: GetBlockOptions) => Promise<{
        block_id: string;
        block_height: string;
        block: BlockJson;
        receipt: BlockReceipt;
    }[]>;
    getBlock: (height: number, opts?: GetBlockOptions) => Promise<{
        block_id: string;
        block_height: string;
        block: BlockJson;
        receipt: BlockReceipt;
    }>;
    wait: (txId: string, type?: "byTransactionId" | "byBlock", timeout?: number) => Promise<{
        blockId: string;
        blockNumber?: number;
    }>;
    sendTransaction: (transaction: TransactionJson | TransactionJsonWait, broadcast?: boolean) => Promise<{
        receipt: TransactionReceipt;
        transaction: TransactionJsonWait;
    }>;
    readContract: (operation: CallContractOperationJson) => Promise<{
        result: string;
        logs: string;
    }>;
    invokeSystemCall: <T = Record<string, unknown>>(serializer: Serializer, nameOrId: string | number, args: Record<string, unknown>, callerData?: {
        caller: string;
        caller_privilege: number;
    }) => Promise<T | undefined>;
    submitBlock?: (block: BlockJson) => Promise<Record<string, never>>;
    getForkHeads?: () => Promise<{
        last_irreversible_block: BlockTopology;
        fork_heads: BlockTopology[];
    }>;
    getResourceLimits?: () => Promise<{
        resource_limit_data: {
            disk_storage_limit: string;
            disk_storage_cost: string;
            network_bandwidth_limit: string;
            network_bandwidth_cost: string;
            compute_bandwidth_limit: string;
            compute_bandwidth_cost: string;
        };
    }>;
    invokeGetContractMetadata?: (contractId: string) => Promise<{
        value: {
            hash: string;
            system: boolean;
            authorizes_call_contract: boolean;
            authorizes_transaction_application: boolean;
            authorizes_upload_contract: boolean;
        };
    } | undefined>;
    invokeGetContractAddress?: (name: string) => Promise<{
        value: {
            address: string;
        };
    } | undefined>;
    invokeGetObject?: (args: {
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }) => Promise<string | undefined>;
    invokeGetNextObject?: (args: {
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }) => Promise<{
        exists: boolean;
        value: string;
        key: string;
    } | undefined>;
    invokeGetPrevObject?: (args: {
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }) => Promise<{
        exists: boolean;
        value: string;
        key: string;
    } | undefined>;
    invokeGetManyObjects?: (args: {
        address: string;
        id: number;
        key?: string;
        limit?: number;
        direction?: "ascending" | "descending";
        system?: boolean;
        zone?: string;
    }) => Promise<{
        exists: boolean;
        value: string;
        key: string;
    }[]>;
}
/**
 * Class to connect with the RPC node
 */
export declare class Provider implements ProviderInterface {
    /**
     * Array of URLs of RPC nodes
     */
    rpcNodes: string[];
    /**
     * Function triggered when a node is down. Returns a
     * boolean determining if the call should be aborted.
     *
     * @example
     * ```ts
     * const provider = new Provider(["https://api.koinos.io"]);
     *
     * provider.onError = (error, node, newNode) => {
     *   console.log(`Error from node ${node}: ${error.message}`);
     *   console.log(`changing node to ${newNode}`);
     *   const abort = false;
     *   return abort;
     * }
     * ```
     */
    onError: (error: Error, 
    /** node that threw the error */
    currentNode: string, 
    /** node used for the next iteration */
    newNode: string) => boolean;
    /**
     * Index of current node in rpcNodes
     */
    currentNodeId: number;
    /**
     *
     * @param rpcNodes - URL of the rpc node, or array of urls
     * to switch between them when someone is down
     * @example
     * ```ts
     * const provider = new Provider([
     *   "https://api.koinos.io",
     *   "https://api.koinosblocks.com"
     * ]);
     * ```
     */
    constructor(rpcNodes: string | string[]);
    /**
     * Function to make jsonrpc requests to the RPC node
     * @param method - jsonrpc method
     * @param params - jsonrpc params
     * @returns Result of jsonrpc response
     *
     * To know the full list of possible calls check the services
     * listed in the [rpc folder of koinos-proto](https://github.com/koinos/koinos-proto/tree/master/koinos/rpc)
     * and the corresponding proto files.
     *
     * @example
     * Let's take "account_history" as an example. Go to [account_history_rpc.proto](https://github.com/koinos/koinos-proto/blob/master/koinos/rpc/account_history/account_history_rpc.proto).
     * The `account_history_request` message has 1 single method: `get_account_history`.
     *
     * Now search the message `get_account_history_request`. This message is telling us
     * the expected fields in the body of the call:
     *
     * ```ts
     * message get_account_history_request {
     *    bytes address = 1 [(btype) = ADDRESS];
     *    optional uint64 seq_num = 2 [jstype = JS_STRING];
     *    uint64 limit = 3 [jstype = JS_STRING];
     *    bool ascending = 4;
     *    bool irreversible = 5;
     * }
     * ```
     *
     * And search the message `get_account_history_response` to see the format of the response:
     * ```ts
     * message get_account_history_response {
     *    repeated account_history_entry values = 1;
     * }
     * ```
     *
     * With this information we can now call the RPC node. It should be done in this way:
     * ```ts
     * const provider = new Provider(["https://api.koinos.io"]);
     * const result = await provider.call(
     *   "account_history.get_account_history",
     *   {
     *     address: "1z629tURV9KAK6Q5yqFDozwSHeWshxXQe",
     *     limit: 2,
     *     ascending: true,
     *     irreversible: true,
     *   }
     * );
     * console.log(result);
     *
     * // {
     * //   "values": [
     * //     {
     * //       "trx": {
     * //         "transaction": {
     * //           "id": "0x12205b566701d6afcf1f5e45b5e9f5443def75728c219f7c1e897ed0ce1ef491223c",
     * //           "header": {
     * //             "chain_id": "EiBZK_GGVP0H_fXVAM3j6EAuz3-B-l3ejxRSewi7qIBfSA==",
     * //             "rc_limit": "961224079493",
     * //             "nonce": "KAE=",
     * //             "operation_merkle_root": "EiA32K_GrZ2VsvWSrM4QZhyEmvm8ID1P6aE4vP00RnY9hg==",
     * //             "payer": "1HyzBsd7nmyUp8dyCJqJZoQRUnzifVzP18"
     * //           },
     * //           "operations": [
     * //             {
     * //               "call_contract": {
     * //                 "contract_id": "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     * //                 "entry_point": 670398154,
     * //                 "args": "ChkAukkLSXtxbRNRTBtDrdAwDI7I6Ot9GxFHEhkACsvmdCIUj89udQ1R5iLPLXzqJoHdliWrGIDC1y8="
     * //               }
     * //             }
     * //           ],
     * //           "signatures": [
     * //             "ICBdTcH6jzhDpl9ZB0ZqNcvSy8wiOokHFtkQ66Lc04K1LhXd77tqaQdMhJOAfYotg5npVmfSgyO9CwgLJmtMIjg="
     * //           ]
     * //         },
     * //         "receipt": {
     * //           "id": "0x12205b566701d6afcf1f5e45b5e9f5443def75728c219f7c1e897ed0ce1ef491223c",
     * //           "payer": "1HyzBsd7nmyUp8dyCJqJZoQRUnzifVzP18",
     * //           "max_payer_rc": "961224079493",
     * //           "rc_limit": "961224079493",
     * //           "rc_used": "3009833",
     * //           "disk_storage_used": "112",
     * //           "network_bandwidth_used": "313",
     * //           "compute_bandwidth_used": "561439",
     * //           "events": [
     * //             {
     * //               "sequence": 2,
     * //               "source": "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     * //               "name": "koinos.contracts.token.transfer_event",
     * //               "data": "ChkAukkLSXtxbRNRTBtDrdAwDI7I6Ot9GxFHEhkACsvmdCIUj89udQ1R5iLPLXzqJoHdliWrGIDC1y8=",
     * //               "impacted": [
     * //                 "1z629tURV9KAK6Q5yqFDozwSHeWshxXQe",
     * //                 "1HyzBsd7nmyUp8dyCJqJZoQRUnzifVzP18"
     * //               ]
     * //             }
     * //           ]
     * //         }
     * //       }
     * //     },
     * //     {
     * //       "seq_num": "1",
     * //       "trx": {
     * //         "transaction": {
     * //           "id": "0x1220a08183a5237e57a08e1ae539017c4253ddfbc23f9b7b6f5e263669aacd3fed47",
     * //           "header": {
     * //             "chain_id": "EiBZK_GGVP0H_fXVAM3j6EAuz3-B-l3ejxRSewi7qIBfSA==",
     * //             "rc_limit": "100000000",
     * //             "nonce": "KAE=",
     * //             "operation_merkle_root": "EiBAmutXQlPyAGctNBNhKEUUEUtwj2KQeNrdFBqpN9RWDg==",
     * //             "payer": "1z629tURV9KAK6Q5yqFDozwSHeWshxXQe"
     * //           },
     * //           "operations": [
     * //             {
     * //               "call_contract": {
     * //                 "contract_id": "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     * //                 "entry_point": 670398154,
     * //                 "args": "ChkACsvmdCIUj89udQ1R5iLPLXzqJoHdliWrEhkAukkLSXtxbRNRTBtDrdAwDI7I6Ot9GxFHGJBO"
     * //               }
     * //             }
     * //           ],
     * //           "signatures": [
     * //             "IF5FBloKjEfnqlGJRL_aPy4L36On-Q8XXzpAQagK_X-xZ6DgioBhZOhKEnhKyhaoROAgGwRuy6BsdRqya8fCHU8="
     * //           ]
     * //         },
     * //         "receipt": {
     * //           "id": "0x1220a08183a5237e57a08e1ae539017c4253ddfbc23f9b7b6f5e263669aacd3fed47",
     * //           "payer": "1z629tURV9KAK6Q5yqFDozwSHeWshxXQe",
     * //           "max_payer_rc": "100000000",
     * //           "rc_limit": "100000000",
     * //           "rc_used": "2657385",
     * //           "disk_storage_used": "35",
     * //           "network_bandwidth_used": "309",
     * //           "compute_bandwidth_used": "566375",
     * //           "events": [
     * //             {
     * //               "sequence": 2,
     * //               "source": "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL",
     * //               "name": "koinos.contracts.token.transfer_event",
     * //               "data": "ChkACsvmdCIUj89udQ1R5iLPLXzqJoHdliWrEhkAukkLSXtxbRNRTBtDrdAwDI7I6Ot9GxFHGJBO",
     * //               "impacted": [
     * //                 "1HyzBsd7nmyUp8dyCJqJZoQRUnzifVzP18",
     * //                 "1z629tURV9KAK6Q5yqFDozwSHeWshxXQe"
     * //               ]
     * //             }
     * //           ]
     * //         }
     * //       }
     * //     }
     * //   ]
     * // }
     * ```
     */
    call<T = unknown>(method: string, params: unknown): Promise<T>;
    /**
     * Function to call "chain.get_account_nonce" to return the number of
     * transactions for a particular account. If you are creating a new
     * transaction consider using [[Provider.getNextNonce]].
     * @param account - account address
     * @param deserialize - If set true it will deserialize the nonce
     * and return it as number (default). If set false it will return
     * the nonce encoded as received from the RPC.
     * @returns Nonce
     */
    getNonce(account: string, deserialize?: boolean): Promise<number | string>;
    /**
     * Function to call "chain.get_account_nonce" (number of
     * transactions for a particular account) and return the next nonce.
     * This call is used when creating new transactions. The result is
     * encoded in base64url
     * @param account - account address
     * @returns Nonce
     */
    getNextNonce(account: string): Promise<string>;
    getAccountRc(account: string): Promise<string>;
    /**
     * Get transactions by id and their corresponding block ids
     */
    getTransactionsById(transactionIds: string[]): Promise<{
        transactions: {
            transaction: TransactionJson;
            containing_blocks: string[];
        }[];
    }>;
    getBlocksById(blockIds: string[], opts?: GetBlockOptions): Promise<{
        block_items: {
            block_id: string;
            block_height: string;
            block: BlockJson;
            receipt: BlockReceipt;
        }[];
    }>;
    /**
     * Function to get info from the head block in the blockchain
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const headInfo = await provider.getHeadInfo();
     * console.log(headInfo);
     *
     * // {
     * //   head_topology: {
     * //     id: '0x12209f7c9b4d695eefd6f87465d490654e495fe25a3d7d2e1eb80658acdc49bad962',
     * //     height: '14957951',
     * //     previous: '0x1220bc3b94e3a2adc3ca09d61a4418df1f4acfa78a69686f592877c194ea50642cd2'
     * //   },
     * //   last_irreversible_block: '14957891',
     * //   head_state_merkle_root: 'EiCriqXooNUXBG23EUKLz2qq3h9ZAC8w1W7w185YQ9MzIA==',
     * //   head_block_time: '1713874497290'
     * // }
     * ```
     */
    getHeadInfo(): Promise<{
        head_block_time: string;
        head_topology: BlockTopology;
        head_state_merkle_root: string;
        last_irreversible_block: string;
    }>;
    /**
     * Function to get the chain
     */
    getChainId(): Promise<string>;
    /**
     * Function to get consecutive blocks in descending order
     * @param height - Starting block height
     * @param numBlocks - Number of blocks to fetch
     * @param idRef - Block ID reference to speed up searching blocks.
     * This ID must be from a greater block height. By default it
     * gets the ID from the block head.
     */
    getBlocks(height: number, numBlocks?: number, idRef?: string, opts?: GetBlockOptions): Promise<{
        block_id: string;
        block_height: string;
        block: BlockJson;
        receipt: BlockReceipt;
    }[]>;
    /**
     * Function to get a block by its height
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const block = await provider.getBlock(14951433);
     * console.log(block);
     *
     * // {
     * //   block_id: '0x1220d5e848eb0f69c590c24cbea4391f89a1055f540bc265c60f6b13c4cc0055ec36',
     * //   block_height: '14951433',
     * //   block: {
     * //     id: '0x1220d5e848eb0f69c590c24cbea4391f89a1055f540bc265c60f6b13c4cc0055ec36',
     * //     header: {
     * //       previous: '0x1220a3c4cbc57ccee4d02b4a1849a9e504122ee93b904deff711d926def2ea2cc878',
     * //       height: '14951433',
     * //       timestamp: '1713854518430',
     * //       previous_state_merkle_root: 'EiCPcnYosMvEBYeCcJrdIJJG0mp4TJ796UGxa0NY6EvzbQ==',
     * //       transaction_merkle_root: 'EiBGPKwttckB7c_BafwnHHmHTBa9S1vKBKauj_yLVNb0tg==',
     * //       signer: '1EPZaqve43k9Jq5mNeT2ydCjUiytTTU4U',
     * //       approved_proposals: [Array]
     * //     },
     * //     transactions: [ [Object] ],
     * //     signature: 'ClEDnHKX1F-pQVbFhmz2qnrwGfP-RbEfTdRFUrvmhmqMeoejtmm2Q0yIPbD5kN5xpIEb
     * //                 8vVwsIJ3lTrgFz2E8w0Paxkgv1E_gMaYNq5UUqtHnl0SIhIgAAbuPHmfMKh9R0Yi5y1D
     * //                 TpjjdN0DYKaIUseXzLiLg_QaQR9jRinZf0g_qo2_4wOx9gDBunIij0r5CycHrNMsuT_V
     * //                 _UvrJOYuwj7aUCA-qnF2tCBQoNQZ3ww7WvKHrMdChxxy'
     * //   },
     * //   receipt: {
     * //     id: '0x1220d5e848eb0f69c590c24cbea4391f89a1055f540bc265c60f6b13c4cc0055ec36',
     * //     height: '14951433',
     * //     disk_storage_used: '35',
     * //     network_bandwidth_used: '760',
     * //     compute_bandwidth_used: '5253506',
     * //     events: [ [Object], [Object] ],
     * //     transaction_receipts: [ [Object] ],
     * //     disk_storage_charged: '35',
     * //     network_bandwidth_charged: '760',
     * //     compute_bandwidth_charged: '5180427',
     * //     state_delta_entries: [
     * //       [Object], [Object],
     * //       [Object], [Object],
     * //       [Object], [Object],
     * //       [Object], [Object],
     * //       [Object], [Object]
     * //     ]
     * //   }
     * // }
     * ```
     *
     * Use the options to get less information. This helps to reduce
     * the bandwidth of the call.
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const block = await provider.getBlock(14951433, {
     *   returnReceipt: false,
     *   returnBlock: false
     * });
     * console.log(block);
     *
     * // {
     * //   block_id: '0x1220d5e848eb0f69c590c24cbea4391f89a1055f540bc265c60f6b13c4cc0055ec36',
     * //   block_height: '14951433'
     * // }
     * ```
     */
    getBlock(height: number, opts?: GetBlockOptions): Promise<{
        block_id: string;
        block_height: string;
        block: BlockJson;
        receipt: BlockReceipt;
    }>;
    /**
     * Function to wait for a transaction to be mined.
     * @param txId - transaction id
     * @param type - Type must be "byBlock" or "byTransactionId" (default).
     * _byBlock_ will query the blockchain to get blocks and search for the
     * transaction there. _byTransactionId_ will query the "transaction store"
     * microservice to search the transaction by its id.
     *
     * @param timeout - Timeout in milliseconds. By default it is 15000
     * @example
     * ```ts
     * const blockNumber = await provider.wait(txId);
     * // const blockNumber = await provider.wait(txId, "byBlock", 15000);
     * // const blockId = await provider.wait(txId, "byTransactionId", 15000);
     * console.log("Transaction mined")
     * ```
     */
    wait(txId: string, type?: "byTransactionId" | "byBlock", timeout?: number): Promise<{
        blockId: string;
        blockNumber?: number;
    }>;
    /**
     * Function to call "chain.submit_transaction" to send a signed
     * transaction to the blockchain.
     *
     * It also has the option to not broadcast the transaction (to not
     * include the transaction the mempool), which is useful if you
     * want to test the interaction with a contract and check the
     * possible events triggered.
     * @param transaction - Transaction
     * @param broadcast - Option to broadcast the transaction to the
     * whole network. By default it is true.
     * @returns It returns the receipt received from the RPC node
     * and the transaction with the arrow function "wait" (see [[wait]])
     */
    sendTransaction(transaction: TransactionJson | TransactionJsonWait, broadcast?: boolean): Promise<{
        receipt: TransactionReceipt;
        transaction: TransactionJsonWait;
    }>;
    /**
     * Function to call "chain.submit_block" to send a signed
     * block to the blockchain.
     */
    submitBlock(block: BlockJson): Promise<Record<string, never>>;
    /**
     * Function to call "chain.read_contract" to read a contract.
     * This function is used by [[Contract]] class when read methods
     * are invoked.
     */
    readContract(operation: CallContractOperationJson): Promise<{
        result: string;
        logs: string;
    }>;
    /**
     * Function to call "chain.get_fork_heads" to get fork heads
     */
    getForkHeads(): Promise<{
        last_irreversible_block: BlockTopology;
        fork_heads: BlockTopology[];
    }>;
    /**
     * Funciont to call "chain.get_resource_limits" to get
     * resource limits
     */
    getResourceLimits(): Promise<{
        resource_limit_data: {
            disk_storage_limit: string;
            disk_storage_cost: string;
            network_bandwidth_limit: string;
            network_bandwidth_cost: string;
            compute_bandwidth_limit: string;
            compute_bandwidth_cost: string;
        };
    }>;
    /**
     * Function to call "chain.invoke_system_call" to invoke a system
     * call.
     */
    invokeSystemCall<T = Record<string, unknown>>(serializer: Serializer, nameOrId: string | number, args: Record<string, unknown>, callerData?: {
        caller: string;
        caller_privilege: number;
    }): Promise<T | undefined>;
    /**
     * Function to get the contract metadata of a specific contract.
     * @param contractId - contract ID
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const result = await provider.invokeGetContractMetadata("15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL");
     * console.log(result);
     *
     * // {
     * //   value: {
     * //     hash: '0x1220c57e3573189868970a3a1662a667c366b15015d9b7900ffed415c5e944036e88',
     * //     system: true,
     * //     authorizes_call_contract: true,
     * //     authorizes_transaction_application: true,
     * //     authorizes_upload_contract: true
     * //   }
     * // }
     *
     * ```
     */
    invokeGetContractMetadata(contractId: string): Promise<{
        value: {
            hash: string;
            system: boolean;
            authorizes_call_contract: boolean;
            authorizes_transaction_application: boolean;
            authorizes_upload_contract: boolean;
        };
    } | undefined>;
    /**
     * Function to get the address of a system contract
     * @param name - contract name
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const result = await provider.invokeGetContractAddress("koin");
     * console.log(result);
     *
     * // { value: { address: '15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL' } }
     * ```
     */
    invokeGetContractAddress(name: string): Promise<{
        value: {
            address: string;
        };
    } | undefined>;
    invokeGetObjectGeneric({ systemCallIdOrName, address, id, key, system, zone, }: {
        systemCallIdOrName: string | number;
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }): Promise<{
        exists: boolean;
        value: string;
        key: string;
    } | undefined>;
    /**
     * Function to get an object from the database via the get_object system call.
     * @param args - object space and key
     * @param args.address - caller address (also used as zone when zone is omitted)
     * @param args.id - object space id
     * @param args.key - object key (defaults to empty)
     * @param args.zone - object space zone (defaults to address)
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const result = await provider.invokeGetObject({
     *   address: "1KD9Es7LBBjA1FY3ViCgQJ7e6WH1ipKbhz",
     *   id: 0,
     * });
     * console.log(result);
     *
     * // {
     * //   exists: true,
     * //   value: '...',
     * //   key: ''
     * // }
     * ```
     */
    invokeGetObject({ address, id, key, system, zone, }: {
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }): Promise<string | undefined>;
    /**
     * Function to get the next object from the database via the
     * get_next_object system call.
     * @param args - object space and key
     * @param args.address - caller address (also used as zone when zone is omitted)
     * @param args.id - object space id
     * @param args.key - object key to seek from (defaults to empty)
     * @param args.system - whether the space is a system space
     * @param args.zone - object space zone (defaults to address)
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const result = await provider.invokeGetNextObject({
     *   address: "1KD9Es7LBBjA1FY3ViCgQJ7e6WH1ipKbhz",
     *   id: 0,
     * });
     * console.log(result);
     *
     * // {
     * //   exists: true,
     * //   value: '...',
     * //   key: '...'
     * // }
     * ```
     */
    invokeGetNextObject({ address, id, key, system, zone, }: {
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }): Promise<{
        exists: boolean;
        value: string;
        key: string;
    } | undefined>;
    /**
     * Function to get the previous object from the database via the
     * get_prev_object system call.
     * @param args - object space and key
     * @param args.address - caller address (also used as zone when zone is omitted)
     * @param args.id - object space id
     * @param args.key - object key to seek from (defaults to empty)
     * @param args.system - whether the space is a system space
     * @param args.zone - object space zone (defaults to address)
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const result = await provider.invokeGetPrevObject({
     *   address: "1KD9Es7LBBjA1FY3ViCgQJ7e6WH1ipKbhz",
     *   id: 0,
     *   key: "...",
     * });
     * console.log(result);
     *
     * // {
     * //   exists: true,
     * //   value: '...',
     * //   key: '...'
     * // }
     * ```
     */
    invokeGetPrevObject({ address, id, key, system, zone, }: {
        address: string;
        id: number;
        key?: string;
        system?: boolean;
        zone?: string;
    }): Promise<{
        exists: boolean;
        value: string;
        key: string;
    } | undefined>;
    /**
     * Function to get many objects from the database by repeatedly
     * calling get_next_object or get_prev_object.
     * @param args - object space and pagination options
     * @param args.address - caller address (also used as zone when zone is omitted)
     * @param args.id - object space id
     * @param args.key - offset key to seek from (defaults to empty)
     * @param args.limit - maximum number of objects to return
     * @param args.direction - traversal direction ("ascending" or "descending")
     * @param args.system - whether the space is a system space
     * @param args.zone - object space zone (defaults to address)
     *
     * @example
     * ```ts
     * const provider = new Provider("https://api.koinos.io");
     * const result = await provider.invokeGetManyObjects({
     *   address: "1KD9Es7LBBjA1FY3ViCgQJ7e6WH1ipKbhz",
     *   id: 0,
     *   limit: 10,
     * });
     * console.log(result);
     *
     * // [
     * //   {
     * //     exists: true,
     * //     value: '...',
     * //     key: '...'
     * //   },
     * //   ...
     * // ]
     * ```
     */
    invokeGetManyObjects({ address, id, key, limit, direction, system, zone, }: {
        address: string;
        id: number;
        key?: string;
        limit?: number;
        direction?: "ascending" | "descending";
        system?: boolean;
        zone?: string;
    }): Promise<{
        exists: boolean;
        value: string;
        key: string;
    }[]>;
}
export default Provider;
